# Bulamogi Media Community: static website

**ONE COMMUNITY. ONE VOICE. ONE FAMILY.**
Connecting People • Sharing Information • Building Unity

A fast, responsive, fully static website (HTML5, CSS3, vanilla JavaScript, Bootstrap 5, Font Awesome, Google Fonts). No PHP, database or server code. It works on GitHub Pages, Netlify or any ordinary web host.

## Pages

`index.html`, `about.html`, `news.html`, `programmes.html`, `people.html`, `opportunities.html`, `community.html`, `contact.html`

## Folder structure

```
bulamogi-media-community/
├── *.html                  generated pages (upload these)
├── assets/
│   ├── css/                style.css (core) + responsive.css (breakpoints)
│   ├── js/                 main.js (shared), search.js (search/filter), news.js (news page)
│   ├── images/             logo.png (transparent), logo.jpg (black background), logo-sm.png, og-image.jpg, hero.svg, news/, programmes/, community/, people/
│   └── icons/              favicon.png, favicon-192.png, apple-touch-icon.png
├── tools/
│   ├── build.py            page generator + ALL editable content and settings
│   └── make_images.py      regenerates the placeholder artwork
├── robots.txt, sitemap.xml, .nojekyll
```

## How to edit content

The header, footer and repeated cards are shared by every page, so the pages are generated from one file.

1. Open `tools/build.py`.
2. Change the **CONFIG** block (site URL, email, phone, WhatsApp, social links) or the **CONTENT** lists (news, people, opportunities, announcements, programmes).
3. Run `python3 tools/build.py` (Python 3, no extra packages). It rewrites the `.html` files, `sitemap.xml` and `robots.txt`.
4. Commit/upload the result.

You can also edit the generated `.html` files directly for one-off changes, but they will be overwritten the next time you run the generator.

## Things you MUST replace before going live

| Item | Where | Notes |
|---|---|---|
| Site address | `SITE_URL` in `tools/build.py` | Used for canonical links, Open Graph and sitemap. Currently `https://example.com/...` |
| Email, phone, WhatsApp number | `CONTACT_EMAIL`, `CONTACT_PHONE`, `WHATSAPP_NUMBER` | WhatsApp number is set to the admin, Mr Mugoya Abasa. **The email is still a placeholder** |
| WhatsApp group invite | `WHATSAPP_GROUP` | Until set, every JOIN OUR COMMUNITY button goes to the Join form on the Contact page |
| Social media pages | `SOCIAL` | Currently link to each platform's home page |
| Physical address | `build_contact()` and footer | Shown as "to be added" |
| Demonstration content | `NEWS`, `PEOPLE`, `OPPS`, `COMMUNITY`, `TICKER` | All sample items are labelled as demonstration content. Replace them with real, verified material |
| Images | `assets/images/` | The official logo is in place. The hero, news, programme, community and profile pictures are generated SVG illustrations (placeholders). Swap in real photographs (optimised JPG/WebP) and update the `<img>` paths |

## Forms (contact, join, newsletter)

A static site cannot receive form submissions by itself. Until a service is configured, the forms **validate input in the browser and clearly say they are demonstration forms. Nothing is sent or stored.**

To make them work, create a form on a service such as Formspree, Getform or Netlify Forms alternatives and paste the endpoint URL into `FORM_ENDPOINT` (contact + join) and `NEWSLETTER_ENDPOINT` (newsletter) in `tools/build.py`, then rebuild. The forms then submit with `fetch()` and show success/error messages.

## Features

Sticky header, responsive hamburger menu, hover dropdowns, breaking-news ticker (pauses on hover), image carousel, smooth scrolling, back-to-top button, news category filter + keyword search (shareable via `?cat=` and `?q=`), searchable opportunities/people/community lists, article/profile/listing detail pop-ups (also reachable by `page.html#id`), image lightbox with keyboard controls, form validation, animated counters, scroll animations (respects reduced-motion), and active-page highlighting.

## Deploy

- **GitHub Pages:** push the folder to a repository, then Settings → Pages → deploy from the main branch (root).
- **Netlify:** drag the folder into Netlify Drop, or connect the repository (no build command, publish directory `/`).
- **Conventional hosting:** upload everything except `tools/` (optional) to `public_html`.

## SEO notes

Each page has a unique title and meta description, Open Graph and Twitter tags, a canonical URL, a single `h1` and descriptive image alt text. `og:image` uses `assets/images/og-image.jpg` (1200×630, the official logo on navy), which works on WhatsApp, Facebook and X.

## Browser support

Current Chrome, Edge, Firefox and Safari, including Android and iOS. Bootstrap, Font Awesome and Google Fonts load from CDNs, so first-time visitors need an internet connection.
