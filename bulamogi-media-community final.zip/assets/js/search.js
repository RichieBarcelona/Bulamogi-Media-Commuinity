/* =====================================================================
   BULAMOGI MEDIA COMMUNITY - search.js
   Generic client-side search + category filtering.

   Markup contract:
     <div class="js-filter-root">
        <input class="js-search">                       (optional search box)
        <button class="chip" data-filter="all|Category"> (optional chips)
        <span class="js-count"></span>                  (optional result counter)
        <div class="js-empty" hidden>...</div>          (optional empty state)
        <... class="js-item" data-category="Category" data-text="searchable text">
     </div>
   Used by news.html, opportunities.html, people.html and community.html.
   ===================================================================== */
(function () {
  'use strict';
  function norm(s) { return (s || '').toLowerCase().replace(/\s+/g, ' ').trim(); }

  function init(root) {
    var input = root.querySelector('.js-search');
    var chips = Array.prototype.slice.call(root.querySelectorAll('.chip[data-filter]'));
    var items = Array.prototype.slice.call(root.querySelectorAll('.js-item'));
    var count = root.querySelector('.js-count');
    var empty = root.querySelector('.js-empty');
    var noun = root.getAttribute('data-noun') || 'result';
    var state = { q: '', cat: 'all' };

    function apply() {
      var terms = norm(state.q).split(' ').filter(Boolean), shown = 0;
      items.forEach(function (it) {
        var catOk = state.cat === 'all' || it.getAttribute('data-category') === state.cat;
        var hay = norm(it.getAttribute('data-text') || it.textContent);
        var qOk = terms.every(function (t) { return hay.indexOf(t) !== -1; });
        var vis = catOk && qOk;
        it.classList.toggle('is-hidden', !vis);
        if (vis) shown++;
      });
      Array.prototype.forEach.call(root.querySelectorAll('.js-section'), function (s) {
        s.classList.toggle('is-hidden', !s.querySelector('.js-item:not(.is-hidden)'));
      });
      var plural = root.getAttribute('data-noun-plural') || noun + 's';
      if (count) count.textContent = shown + ' ' + (shown === 1 ? noun : plural) + ' found';
      if (empty) empty.hidden = shown !== 0;
      var evt = new CustomEvent('bmc:filtered', { detail: { shown: shown, state: state }, bubbles: true });
      root.dispatchEvent(evt);
    }
    function setCat(cat) {
      state.cat = cat;
      chips.forEach(function (c) {
        var on = c.getAttribute('data-filter') === cat;
        c.classList.toggle('active', on);
        c.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      apply();
    }
    if (input) input.addEventListener('input', function () { state.q = input.value; apply(); });
    var form = input && input.closest('form');
    if (form) form.addEventListener('submit', function (e) { e.preventDefault(); });
    chips.forEach(function (c) { c.addEventListener('click', function () { setCat(c.getAttribute('data-filter')); }); });

    root._bmc = { setCat: setCat, setQuery: function (q) { state.q = q; if (input) input.value = q; apply(); } };
    setCat('all');
  }

  window.BMCFilter = { init: init };
  Array.prototype.forEach.call(document.querySelectorAll('.js-filter-root'), init);
})();
