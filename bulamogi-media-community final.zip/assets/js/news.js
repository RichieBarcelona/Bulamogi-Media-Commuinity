/* =====================================================================
   BULAMOGI MEDIA COMMUNITY - news.js
   News-page specifics on top of search.js:
   - honours ?cat=Education and ?q=text in the URL (used by category labels on the homepage)
   - keeps the URL in sync so a filtered view can be shared
   - "clear filters" button
   ===================================================================== */
(function () {
  'use strict';
  var root = document.querySelector('#newsRoot');
  if (!root) return;

  function ready() {
    var api = root._bmc;
    if (!api) { return setTimeout(ready, 20); }
    var params = new URLSearchParams(location.search);
    var cat = params.get('cat'), q = params.get('q');
    if (cat) {
      var chip = Array.prototype.slice.call(root.querySelectorAll('.chip[data-filter]')).filter(function (c) { return c.getAttribute('data-filter') === cat; })[0];
      if (chip) api.setCat(cat);
    }
    if (q) api.setQuery(q);

    root.addEventListener('bmc:filtered', function (e) {
      var s = e.detail.state, p = new URLSearchParams();
      if (s.cat !== 'all') p.set('cat', s.cat);
      if (s.q) p.set('q', s.q);
      var qs = p.toString();
      history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '') + (location.hash || ''));
    });

    var clear = document.querySelector('#clearFilters');
    if (clear) clear.addEventListener('click', function () { api.setQuery(''); api.setCat('all'); });
  }
  ready();
})();
