/* =====================================================================
   BULAMOGI MEDIA COMMUNITY - main.js
   Shared behaviour on every page (vanilla JS, no dependencies besides Bootstrap's bundle)
   ===================================================================== */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  document.documentElement.classList.remove('no-js');

  /* ---------- sticky header shadow + back-to-top ---------- */
  var header = $('.site-header');
  var toTop = $('#toTop');
  function onScroll() {
    var y = window.pageYOffset || document.documentElement.scrollTop;
    if (header) header.classList.toggle('scrolled', y > 10);
    if (toTop) toTop.classList.toggle('show', y > 500);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  if (toTop) toTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* ---------- active navigation highlighting ---------- */
  var page = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  if (page === '') page = 'index.html';
  $$('.navbar .nav-link[data-page]').forEach(function (a) {
    var pages = a.getAttribute('data-page').split(',');
    if (pages.indexOf(page) !== -1) { a.classList.add('active'); a.setAttribute('aria-current', 'page'); }
  });

  /* ---------- close mobile menu after choosing a link ---------- */
  var menu = $('#mainNav');
  if (menu && window.bootstrap) {
    $$('a.nav-link:not(.dropdown-toggle), .dropdown-item, .btn-join', menu).forEach(function (a) {
      a.addEventListener('click', function () {
        if (menu.classList.contains('show')) bootstrap.Collapse.getOrCreateInstance(menu).hide();
      });
    });
  }

  /* ---------- smooth scrolling for same-page anchors (offset for sticky header) ---------- */
  $$('a[href*="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (a.classList.contains('js-detail')) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (err) { return; }
      if (url.pathname !== location.pathname || !url.hash || url.hash === '#') return;
      var target = document.getElementById(decodeURIComponent(url.hash.slice(1)));
      if (!target) return;
      e.preventDefault();
      var top = target.getBoundingClientRect().top + window.pageYOffset - (header ? header.offsetHeight : 0) - 8;
      window.scrollTo({ top: top, behavior: 'smooth' });
      history.pushState(null, '', url.hash);
    });
  });

  /* ---------- breaking-news ticker: duplicate content for a seamless loop ---------- */
  $$('.ticker-move').forEach(function (m) { m.innerHTML += m.innerHTML; $$('a', m).slice(m.children.length / 2).forEach(function (a) { a.setAttribute('aria-hidden', 'true'); a.tabIndex = -1; }); });

  /* ---------- scroll reveal animations ---------- */
  var reveals = $$('.reveal');
  if ('IntersectionObserver' in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    reveals.forEach(function (r) { io.observe(r); });
  } else { reveals.forEach(function (r) { r.classList.add('in'); }); }

  /* ---------- animated counters ---------- */
  var counters = $$('.count');
  function runCounter(el) {
    var end = parseInt(el.getAttribute('data-count'), 10) || 0, dur = 1400, start = null;
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      el.textContent = Math.floor(p * end);
      if (p < 1) requestAnimationFrame(step); else el.textContent = end;
    }
    requestAnimationFrame(step);
  }
  if ('IntersectionObserver' in window && counters.length) {
    var co = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { runCounter(en.target); co.unobserve(en.target); } });
    }, { threshold: 0.6 });
    counters.forEach(function (c) { co.observe(c); });
  } else { counters.forEach(function (c) { c.textContent = c.getAttribute('data-count'); }); }

  /* ---------- image lightbox ---------- */
  var lbLinks = $$('[data-lightbox]');
  if (lbLinks.length) {
    var lb = document.createElement('div');
    lb.className = 'lightbox';
    lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Image viewer');
    lb.innerHTML = '<button class="lb-btn lb-close" aria-label="Close image viewer"><i class="fa-solid fa-xmark"></i></button>' +
      '<button class="lb-btn lb-prev" aria-label="Previous image"><i class="fa-solid fa-chevron-left"></i></button>' +
      '<figure><img alt=""><figcaption></figcaption></figure>' +
      '<button class="lb-btn lb-next" aria-label="Next image"><i class="fa-solid fa-chevron-right"></i></button>';
    document.body.appendChild(lb);
    var lbImg = $('img', lb), lbCap = $('figcaption', lb), idx = 0, opener = null;
    var show = function (i) {
      idx = (i + lbLinks.length) % lbLinks.length;
      var a = lbLinks[idx], im = $('img', a);
      lbImg.src = a.getAttribute('href'); lbImg.alt = im ? im.alt : '';
      lbCap.textContent = a.getAttribute('data-caption') || (im ? im.alt : '');
    };
    var open = function (i, from) { opener = from; show(i); lb.classList.add('open'); document.body.style.overflow = 'hidden'; $('.lb-close', lb).focus(); };
    var close = function () { lb.classList.remove('open'); document.body.style.overflow = ''; if (opener) opener.focus(); };
    lbLinks.forEach(function (a, i) { a.addEventListener('click', function (e) { e.preventDefault(); open(i, a); }); });
    $('.lb-close', lb).addEventListener('click', close);
    $('.lb-prev', lb).addEventListener('click', function () { show(idx - 1); });
    $('.lb-next', lb).addEventListener('click', function () { show(idx + 1); });
    lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
    document.addEventListener('keydown', function (e) {
      if (!lb.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') show(idx - 1);
      if (e.key === 'ArrowRight') show(idx + 1);
    });
  }

  /* ---------- detail modal (news articles, profiles, opportunities, announcements) ----------
     A card marked .detail-card (with an id) carries a hidden .detail-body. Clicking its
     .js-detail link, or visiting page.html#card-id, opens it in a Bootstrap modal. */
  var modalEl = null, modal = null;
  function buildModal() {
    modalEl = document.createElement('div');
    modalEl.className = 'modal fade'; modalEl.tabIndex = -1; modalEl.setAttribute('aria-labelledby', 'detailTitle'); modalEl.setAttribute('aria-hidden', 'true');
    modalEl.innerHTML = '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg"><div class="modal-content">' +
      '<div class="modal-header"><h2 class="modal-title" id="detailTitle"></h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>' +
      '<div class="modal-body"><img alt="" hidden><div class="detail-meta meta"></div><div class="detail-content"></div></div>' +
      '<div class="modal-footer"><span class="demo-badge me-auto">Demonstration content</span><button type="button" class="btn btn-navy btn-sm-x" data-bs-dismiss="modal">Close</button></div>' +
      '</div></div>';
    document.body.appendChild(modalEl);
    modal = new bootstrap.Modal(modalEl);
    modalEl.addEventListener('hidden.bs.modal', function () {
      if (location.hash && document.getElementById(location.hash.slice(1)) && document.getElementById(location.hash.slice(1)).classList.contains('detail-card')) {
        history.replaceState(null, '', location.pathname + location.search);
      }
    });
  }
  function openDetail(card) {
    if (!window.bootstrap || !card) return;
    var body = $('.detail-body', card); if (!body) return;
    if (!modal) buildModal();
    $('#detailTitle', modalEl).textContent = ($('.detail-title', card) || {}).textContent || '';
    var im = $('img', card), mi = $('.modal-body img', modalEl);
    if (im) { mi.src = im.getAttribute('src'); mi.alt = im.alt; mi.hidden = false; } else { mi.hidden = true; }
    var metaSrc = $('.detail-meta-src', card);
    $('.detail-meta', modalEl).innerHTML = metaSrc ? metaSrc.innerHTML : '';
    $('.detail-content', modalEl).innerHTML = body.innerHTML;
    modal.show();
  }
  $$('.js-detail').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var card = a.closest('.detail-card');
      if (card) { openDetail(card); history.replaceState(null, '', '#' + card.id); }
    });
  });
  function openFromHash() {
    if (!location.hash) return;
    var el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (el && el.classList.contains('detail-card')) openDetail(el);
  }
  window.addEventListener('load', openFromHash);
  window.addEventListener('hashchange', openFromHash);

  /* ---------- form validation + demo handling ----------
     Forms with data-endpoint="https://..." (Formspree, Netlify Forms alternative, Getform, etc.)
     are submitted with fetch(). Without an endpoint the form is a clearly-labelled demonstration. */
  var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function fieldOk(f) {
    var v = (f.value || '').trim(), ok = true;
    if (f.required && f.type === 'checkbox') ok = f.checked;
    else if (f.required && !v) ok = false;
    else if (f.type === 'email' && v) ok = emailRe.test(v);
    else if (f.getAttribute('data-minlength') && v) ok = v.length >= parseInt(f.getAttribute('data-minlength'), 10);
    f.classList.toggle('is-invalid', !ok);
    f.classList.toggle('is-valid', ok && !!v);
    return ok;
  }
  $$('form.js-form').forEach(function (form) {
    form.setAttribute('novalidate', '');
    var status = $('.form-status', form);
    $$('input,textarea,select', form).forEach(function (f) {
      f.addEventListener('blur', function () { if (f.type !== 'hidden') fieldOk(f); });
      f.addEventListener('input', function () { if (f.classList.contains('is-invalid')) fieldOk(f); });
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var hp = $('input[name="_gotcha"]', form);
      if (hp && hp.value) return; // honeypot
      var allOk = true, first = null;
      $$('input,textarea,select', form).forEach(function (f) { if (f.type === 'hidden' || f.name === '_gotcha') return; if (!fieldOk(f)) { allOk = false; if (!first) first = f; } });
      if (!allOk) { if (first) first.focus(); show('danger', '<i class="fa-solid fa-circle-exclamation me-2"></i>Please correct the highlighted fields and try again.'); return; }
      var endpoint = form.getAttribute('data-endpoint');
      if (!endpoint) {
        show('warning', '<i class="fa-solid fa-flask me-2"></i><strong>Demonstration form.</strong> Your details were checked in your browser but <strong>nothing was sent or stored</strong>, because no form service has been configured yet. Please reach us on WhatsApp or email instead.');
        return;
      }
      var btn = $('button[type="submit"]', form); if (btn) { btn.disabled = true; }
      fetch(endpoint, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
        .then(function (r) { if (!r.ok) throw new Error('bad'); form.reset(); $$('.is-valid', form).forEach(function (f) { f.classList.remove('is-valid'); }); show('success', '<i class="fa-solid fa-circle-check me-2"></i>Thank you! Your message has been sent.'); })
        .catch(function () { show('danger', '<i class="fa-solid fa-triangle-exclamation me-2"></i>Sorry, we could not send that right now. Please try again or contact us on WhatsApp.'); })
        .then(function () { if (btn) btn.disabled = false; });
    });
    function show(type, html) {
      if (!status) return;
      status.className = 'form-status show alert alert-' + type;
      status.setAttribute('role', 'alert');
      status.innerHTML = html;
    }
  });
})();
