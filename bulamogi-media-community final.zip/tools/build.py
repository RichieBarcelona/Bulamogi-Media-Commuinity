#!/usr/bin/env python3
"""Static page generator for the Bulamogi Media Community website.

Why a generator? The header, footer and cards repeat on every page. Keeping them in one
place means one edit updates the whole site. The OUTPUT is plain static HTML - nothing here
runs on the server. Edit the CONFIG and CONTENT sections, then run:

    python3 tools/build.py

and upload/commit the generated *.html files together with assets/.
"""
import html
import os
import urllib.parse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# =====================================================================
# CONFIG  - replace the placeholders below, rebuild, redeploy
# =====================================================================
SITE_NAME = "Bulamogi Media Community"
SITE_URL = "https://example.com/bulamogi-media-community"   # <- your real address, no trailing slash
SLOGAN = "ONE COMMUNITY. ONE VOICE. ONE FAMILY."
TAGLINE = "Connecting People • Sharing Information • Building Unity"
CONTACT_EMAIL = "info@bulamogimedia.example"                 # PLACEHOLDER
CONTACT_PHONE = "+256 782 496 465"                           # WhatsApp admin: Mr Mugoya Abasa
WHATSAPP_NUMBER = "256782496465"                             # WhatsApp admin (digits only, with country code)
WHATSAPP_ADMIN = "Mr Mugoya Abasa"
WHATSAPP_GROUP = ""            # paste the official WhatsApp group invite link here when you have it
FORM_ENDPOINT = ""             # e.g. https://formspree.io/f/xxxxxxxx  (empty = demonstration form)
NEWSLETTER_ENDPOINT = ""       # e.g. a Formspree / Buttondown / Mailchimp form action URL
LASTMOD = "2026-11-11"

WA_TEXT = urllib.parse.quote("Hello Mr Mugoya Abasa, I would like to connect with Bulamogi Media Community.")
WA_LINK = "https://wa.me/%s?text=%s" % (WHATSAPP_NUMBER, WA_TEXT)
JOIN_URL = WHATSAPP_GROUP or "contact.html#join"
JOIN_EXTERNAL = bool(WHATSAPP_GROUP)

# Official social pages: replace the generic platform links with your real page URLs.
SOCIAL = [
    ("Facebook", "fa-brands fa-facebook-f", "https://www.facebook.com/"),
    ("X (Twitter)", "fa-brands fa-x-twitter", "https://x.com/"),
    ("YouTube", "fa-brands fa-youtube", "https://www.youtube.com/"),
    ("Instagram", "fa-brands fa-instagram", "https://www.instagram.com/"),
    ("TikTok", "fa-brands fa-tiktok", "https://www.tiktok.com/"),
    ("WhatsApp", "fa-brands fa-whatsapp", WA_LINK),
]

# =====================================================================
# CONTENT (all sample/demonstration content is labelled as such on the pages)
# =====================================================================
PILLARS = [
    ("fa-people-group", "BRINGING PEOPLE TOGETHER, NEAR AND FAR",
     "Uniting Bulamogi people regardless of distance, background, age or profession."),
    ("fa-tower-broadcast", "LIVE UPDATES – LOCAL, NATIONAL AND INTERNATIONAL",
     "Providing reliable and timely information about important happenings in Bulamogi, Uganda and the world."),
    ("fa-hand-holding-heart", "STANDING TOGETHER IN HAPPINESS AND IN DIFFICULT TIMES",
     "Celebrating achievements, supporting families and standing together during challenging moments."),
]

PILLAR_DETAILS = [
    dict(label="PILLAR ONE",
         paras=["We aim to unite the people of Bulamogi regardless of distance, background, age, profession or social standing.",
                "We want to create a space where people can interact, exchange ideas, reconnect with old friends, build meaningful relationships and work together for the betterment of our community."],
         items=[], closing="Distance should never separate us, and our differences should never divide us."),
    dict(label="PILLAR TWO",
         paras=["Information is power, and an informed community is an empowered community.",
                "Bulamogi Community Media will strive to keep our people updated on important happenings within Bulamogi, across Uganda and around the world."],
         items=["Local community news and developments.", "National and international news.", "Education, health and business updates.",
                "Government programmes and public announcements.", "Employment, scholarships and other opportunities.", "Important social, cultural and community events."],
         items_title="We shall share:",
         closing="We shall promote accuracy, fairness, responsible reporting and timely information sharing."),
    dict(label="PILLAR THREE",
         paras=["A true community stands together not only during good times but also when life becomes difficult.",
                "We believe in celebrating one another's achievements, sharing moments of happiness, supporting families during challenging times, comforting those who are grieving and standing with anyone in need of encouragement or assistance.",
                "Whether it is a wedding, graduation, birth, achievement, illness, loss or any other significant life event, we want everyone to feel that they are part of a family that cares."],
         items=[], closing="Our strength lies in our unity, compassion and willingness to support one another."),
]

PROGRAMMES = [
    dict(slug="bulamogi-today", title="Bulamogi Today", icon="fa-newspaper",
         short="A regular news and information segment bringing the latest happenings, announcements and developments from within Bulamogi.",
         long="Our flagship news service gathers verified local happenings, official notices and community announcements so that every family hears important news at the same time, wherever they live.",
         bullets=["Latest happenings from within Bulamogi", "Announcements and developments", "Short, clear updates that are easy to share"]),
    dict(slug="people-of-bulamogi", title="People of Bulamogi", icon="fa-star",
         short="Recognising and celebrating outstanding individuals, professionals, entrepreneurs, leaders, students and people making positive contributions to society.",
         long="Every community has people whose work and character lift others. This programme tells their stories so that young people can see what is possible and the whole community can say thank you.",
         bullets=["Outstanding individuals and professionals", "Entrepreneurs, leaders and students", "Nominations open to the whole community"]),
    dict(slug="our-community-our-responsibility", title="Our Community, Our Responsibility", icon="fa-handshake",
         short="Promoting community development, volunteerism, fundraising initiatives, social responsibility and collective efforts to improve the wellbeing of our people.",
         long="Development is not something that only happens to a community; it is something a community does. We create space for constructive discussion and practical action on the issues that matter to Bulamogi families.",
         bullets=["Community development and volunteerism", "Fundraising initiatives and social responsibility", "Collective efforts for the wellbeing of our people"]),
    dict(slug="celebrating-with-you", title="Celebrating With You", icon="fa-cake-candles",
         short="A special space for birthdays, weddings, graduations, anniversaries, births, promotions and other memorable achievements.",
         long="Life's happy moments are better shared. Send us your good news and we will celebrate it with the wider Bulamogi family, near and far.",
         bullets=["Birthday, wedding and anniversary greetings", "Graduations, promotions and achievements", "Birth announcements and welcome messages"]),
    dict(slug="together-in-difficult-times", title="Together in Difficult Times", icon="fa-hand-holding-heart",
         short="A compassionate platform for sharing condolences, supporting bereaved families, highlighting emergencies and mobilising community assistance.",
         long="When a family is grieving or a community faces an emergency, information and compassion matter most. We share notices respectfully and help organise support.",
         bullets=["Condolences and support for bereaved families", "Highlighting emergencies", "Mobilising community assistance"]),
    dict(slug="bulamogi-worldwide", title="Bulamogi Worldwide", icon="fa-earth-africa",
         short="Connecting people of Bulamogi living in different parts of Uganda and across the world. Sharing their experiences, achievements, ideas and contributions while strengthening the bond between those at home and abroad.",
         long="Distance does not end belonging. Bulamogi Worldwide links those at home with those abroad, sharing experiences, networks and ways of giving back.",
         bullets=["Experiences, achievements and ideas from abroad", "Connections between home and abroad", "Contributions that strengthen the bond with home"]),
    dict(slug="opportunities-corner", title="Opportunities Corner", icon="fa-briefcase",
         short="A dedicated space for sharing job opportunities, scholarships, business opportunities, training programmes, tenders and other opportunities that can improve the lives of our people.",
         long="Information is opportunity. We collect and share openings so that talent in Bulamogi is not limited by lack of information.",
         bullets=["Job opportunities and scholarships", "Business opportunities and tenders", "Training programmes and other openings"]),
]

NEWS_CATS = ["Local News", "National News", "International News", "Education", "Health", "Business", "Community Development"]

NEWS = [
    dict(id="n1", cat="Local News", date="10 Nov 2026", title="Community Leaders Meet to Plan Year-End Development Priorities",
         excerpt="Sample story: leaders and residents come together to agree on priorities for the final weeks of the year.",
         body=["This is demonstration content showing how a full local news story will appear on the website. Replace it with real reporting from Bulamogi.",
               "A good local story answers who, what, where, when and why, quotes real people with their permission, and clearly states the source of every fact."]),
    dict(id="n2", cat="Education", date="09 Nov 2026", title="Preparing Strong Scholarship Applications: Tips for Students",
         excerpt="Sample story: practical advice for students preparing documents and personal statements.",
         body=["Demonstration content. In a real article this space would explain how to prepare transcripts, recommendation letters and a personal statement ahead of deadlines.",
               "Always confirm requirements and dates with the official scholarship provider before applying."]),
    dict(id="n3", cat="Health", date="08 Nov 2026", title="Simple Steps to Protect Family Health in the Community",
         excerpt="Sample story: everyday habits that help families stay healthy, with reminders to consult health workers.",
         body=["Demonstration content. Health stories on this platform should be checked against guidance from qualified health professionals and official health authorities.",
               "Where relevant, readers will be pointed to their nearest health facility for personal medical advice."]),
    dict(id="n4", cat="Business", date="06 Nov 2026", title="Young Entrepreneurs Grow Small Businesses Close to Home",
         excerpt="Sample story: how local enterprises create jobs and keep value in the community.",
         body=["Demonstration content. Business features will highlight real entrepreneurs, with their consent, and practical lessons others can learn from.",
               "Readers can nominate a business through the Contact page."]),
    dict(id="n5", cat="National News", date="05 Nov 2026", title="National Updates Every Bulamogi Family Should Know This Month",
         excerpt="Sample story: a plain-language summary of national announcements that affect households.",
         body=["Demonstration content. National updates will be summarised from official and reputable sources, with links so readers can check the facts themselves.",
               "We do not publish rumours or unverified claims."]),
    dict(id="n6", cat="International News", date="03 Nov 2026", title="Bulamogi Sons and Daughters Abroad Build a Support Network",
         excerpt="Sample story: community members living overseas connect to support each other and projects back home.",
         body=["Demonstration content. This is where stories from the Bulamogi diaspora and international news relevant to our readers will appear.",
               "Members abroad are invited to share their experiences through the Contact page."]),
    dict(id="n7", cat="Community Development", date="02 Nov 2026", title="Villages Join Hands to Improve Roads and Water Points",
         excerpt="Sample story: residents pool effort and resources for a shared local improvement project.",
         body=["Demonstration content. Development stories will show what communities achieve together and how others can take part.",
               "Project names, costs and dates will only be published when they can be verified."]),
    dict(id="n8", cat="Education", date="01 Nov 2026", title="A Parent's Checklist for the Coming School Term",
         excerpt="Sample story: a short checklist to help families prepare children for school.",
         body=["Demonstration content. Education stories will include school notices, exam information and guidance for parents and learners.",
               "Always check dates with the school or the Ministry of Education and Sports."]),
]

TICKER = [
    ("Welcome to Bulamogi Media Community – your community, your people, your voice.", "about.html"),
    ("Sample: Community planning meeting announced for early December (demonstration)", "community.html#events"),
    ("Sample: Scholarship applications open for Bulamogi students (demonstration)", "opportunities.html"),
    ("Sample: Community health outreach planned (demonstration)", "news.html?cat=Health"),
    ("Send us your news, celebrations and announcements – contact our team today", "contact.html"),
]

PEOPLE_ROLES = ["Entrepreneur", "Professional", "Community Leader", "Student", "Development"]
PEOPLE = [
    dict(id="p1", role="Entrepreneur", headline="Building Business from the Ground Up",
         short="Demonstration profile of a local entrepreneur who creates jobs and opportunities.",
         body=["This is a demonstration profile. A real profile would tell the story of an entrepreneur from Bulamogi, what they built, the challenges they overcame and the advice they offer others.",
               "Profiles are published only with the person's permission."]),
    dict(id="p2", role="Professional", headline="Teaching the Next Generation",
         short="Demonstration profile of an educator inspiring learners across the community.",
         body=["Demonstration profile. Educators, engineers, accountants, lawyers and other professionals from Bulamogi will be celebrated here.",
               "Nominate someone through the Contact page."]),
    dict(id="p3", role="Professional", headline="Caring for Community Health",
         short="Demonstration profile of a health worker serving families with dedication.",
         body=["Demonstration profile. Health workers and caregivers keep our families well, and their stories deserve to be told.",
               "This is sample text to be replaced with a real story."]),
    dict(id="p4", role="Community Leader", headline="Leading with Service",
         short="Demonstration profile of a leader who puts the community first.",
         body=["Demonstration profile. Community leaders, elders, faith and cultural leaders who serve with integrity will be featured here.",
               "This is sample text to be replaced with a real story."]),
    dict(id="p5", role="Student", headline="A Student with Big Dreams",
         short="Demonstration profile of a young achiever working hard to reach their goals.",
         body=["Demonstration profile. We celebrate students who excel in class, sport, arts and innovation, and the families and teachers who support them.",
               "This is sample text to be replaced with a real story."]),
    dict(id="p6", role="Development", headline="Volunteering for Development",
         short="Demonstration profile of a volunteer driving community improvement projects.",
         body=["Demonstration profile. Volunteers and organisers who give their time and skills to develop Bulamogi will be recognised here.",
               "This is sample text to be replaced with a real story."]),
]

OPP_CATS = ["Employment", "Scholarship", "Business", "Training", "Tender", "Government"]
OPPS = [
    dict(id="o1", cat="Employment", icon="fa-user-tie", title="Sample Job Opening: Community Programmes Officer",
         desc="Demonstration listing showing how a job vacancy will appear, with employer, location and deadline.",
         deadline="31 Dec 2026", link="https://psc.go.ug", link_label="Official public jobs portal",
         body=["Demonstration listing. A real vacancy would include the employer, duties, qualifications, location and how to apply.",
               "Always verify vacancies directly with the employer. We never ask applicants for money."]),
    dict(id="o2", cat="Employment", icon="fa-laptop-code", title="Sample Internship: Digital Media Assistant",
         desc="Demonstration listing for a short internship placement for young people.",
         deadline="15 Jan 2027", link=None, link_label=None,
         body=["Demonstration listing. Internship notices will explain duration, allowances (if any) and how to apply.",
               "No external link has been provided for this sample."]),
    dict(id="o3", cat="Scholarship", icon="fa-graduation-cap", title="Sample Scholarship: Undergraduate Support Programme",
         desc="Demonstration listing explaining eligibility and the documents applicants will need.",
         deadline="28 Feb 2027", link="https://www.education.go.ug", link_label="Ministry of Education and Sports",
         body=["Demonstration listing. Real scholarship notices will link to the provider's official application page.",
               "Check all requirements and dates with the scholarship provider."]),
    dict(id="o4", cat="Scholarship", icon="fa-book-open-reader", title="Sample Scholarship: Postgraduate Study Abroad",
         desc="Demonstration listing for postgraduate funding opportunities.",
         deadline="30 Mar 2027", link=None, link_label=None,
         body=["Demonstration listing. Postgraduate and overseas opportunities will be shared as providers announce them.",
               "No external link has been provided for this sample."]),
    dict(id="o5", cat="Business", icon="fa-store", title="Sample Business Opportunity: Agribusiness Partnership",
         desc="Demonstration listing about partnering on a local value-addition project.",
         deadline=None, link="https://www.ugandainvest.go.ug", link_label="Uganda Investment Authority",
         body=["Demonstration listing. Business notices will describe the opportunity, investment needed and contact details.",
               "Do your own due diligence before committing money to any venture."]),
    dict(id="o6", cat="Training", icon="fa-chalkboard-user", title="Sample Training: Digital Skills for Youth",
         desc="Demonstration listing for a skills training programme open to young people.",
         deadline="20 Dec 2026", link=None, link_label=None,
         body=["Demonstration listing. Training notices will include dates, venue or online link, cost and how to register.",
               "No external link has been provided for this sample."]),
    dict(id="o7", cat="Tender", icon="fa-file-contract", title="Sample Tender Notice: Local Supplies and Services",
         desc="Demonstration listing showing how public tender notices will be summarised.",
         deadline="10 Jan 2027", link="https://www.ppda.go.ug", link_label="Public Procurement authority",
         body=["Demonstration listing. Tender summaries will always point to the official notice, which is the only authoritative source.",
               "Never rely on a summary alone when bidding."]),
    dict(id="o8", cat="Government", icon="fa-landmark", title="Sample Government Programme: Community Support Scheme",
         desc="Demonstration listing explaining a public programme and who can benefit.",
         deadline=None, link="https://www.gou.go.ug", link_label="Government of Uganda portal",
         body=["Demonstration listing. Programme notices will explain who qualifies and where to apply through official channels.",
               "Government programmes are free to apply for unless officially stated otherwise."]),
]

COMMUNITY_SECTIONS = [
    ("events", "Meetings & Events", "fa-calendar-days", "event"),
    ("celebrations", "Celebrations", "fa-cake-candles", "celebration"),
    ("condolences", "Condolences & Support", "fa-dove", "condolence"),
    ("announcements", "Important Announcements", "fa-bullhorn", "announcement"),
]
COMMUNITY = [
    dict(id="ev1", sec="events", day="06", mon="DEC", title="Community Planning Meeting (Sample)", where="Venue to be announced",
         desc="Demonstration notice for a community meeting about local priorities.",
         body=["Demonstration notice. A real meeting notice would give the date, time, venue, agenda and who should attend."]),
    dict(id="ev2", sec="events", day="20", mon="DEC", title="Bulamogi Worldwide Online Gathering (Sample)", where="Online",
         desc="Demonstration notice for a virtual get-together for members at home and abroad.",
         body=["Demonstration notice. Online gatherings will include the meeting link and time zones for members abroad."]),
    dict(id="ce1", sec="celebrations", day="12", mon="DEC", title="Congratulations to Our Graduates (Sample)", where="Community-wide",
         desc="Demonstration message celebrating graduates and their families.",
         body=["Demonstration message. Send us the graduate's name, course and a short note to celebrate with the community."]),
    dict(id="ce2", sec="celebrations", day="19", mon="DEC", title="Wedding Celebration Announcement (Sample)", where="Details provided by family",
         desc="Demonstration announcement of a wedding, with congratulations from the community.",
         body=["Demonstration announcement. Families can share wedding details, photographs and greetings through the Contact page."]),
    dict(id="ce3", sec="celebrations", day="03", mon="JAN", title="Welcome, Little One! Birth Announcement (Sample)", where="Community-wide",
         desc="Demonstration birth announcement welcoming a new member of the family.",
         body=["Demonstration announcement. Share the happy news of a new arrival with the Bulamogi family."]),
    dict(id="co1", sec="condolences", day="•", mon="IN MEMORY", title="In Loving Memory: Sample Notice", where="Details provided by family",
         desc="Demonstration of a respectful bereavement notice. No real person is named.",
         body=["Demonstration notice, no real person is named. Real notices will be published only with the family's consent and will include arrangements they wish to share.",
               "May the families who are grieving find comfort in the support of their community."]),
    dict(id="co2", sec="condolences", day="•", mon="SUPPORT", title="Community Support Appeal (Sample)", where="Organised with the family's agreement",
         desc="Demonstration of how a community support initiative would be shared.",
         body=["Demonstration notice. Support appeals will name a verified contact and will never ask for money without the family's knowledge and agreement."]),
    dict(id="an1", sec="announcements", day="•", mon="NOTICE", title="How to Submit Your Announcement", where="Contact page or WhatsApp",
         desc="Share your community announcement with us: what to send and how it is reviewed.",
         body=["Send the details of your announcement by WhatsApp or email, or use the Contact page. Our team checks facts and may contact you before publishing.",
               "We do not publish personal attacks, misinformation or divisive content."]),
    dict(id="an2", sec="announcements", day="•", mon="ALERT", title="Emergency Update Format (Sample)", where="Community-wide",
         desc="Demonstration of how urgent updates will be formatted: what happened, where, and what to do.",
         body=["Demonstration notice. Emergency updates will be short and clear, and will always point to official instructions from authorities."]),
]

VALUES = [("fa-link", "Unity", "Promoting togetherness regardless of our differences."),
          ("fa-scale-balanced", "Truth and Integrity", "Sharing accurate, responsible and trustworthy information."),
          ("fa-face-smile", "Respect", "Valuing every individual and opinion."),
          ("fa-eye", "Transparency", "Encouraging openness and accountability."),
          ("fa-heart", "Compassion", "Caring for and supporting one another."),
          ("fa-people-group", "Inclusiveness", "Giving everyone an opportunity to participate and be heard."),
          ("fa-seedling", "Development", "Promoting ideas and initiatives that improve our community."),
          ("fa-circle-check", "Responsibility", "Using media positively and constructively.")]

GALLERY = [("c%d.svg" % i, alt) for i, alt in enumerate([
    "Illustration of a community gathering", "Illustration of a celebration with confetti", "Illustration of a graduation cap",
    "Illustration of the sun rising over Bulamogi", "Illustration of a broadcast signal connecting people",
    "Illustration of a heart for community care", "Illustration of a memorial candle", "Illustration of a microphone for community voices"], 1)]

PAGES = [  # file, nav label, priority
    ("index.html", 1.0), ("about.html", .8), ("news.html", .9), ("programmes.html", .8),
    ("people.html", .7), ("opportunities.html", .8), ("community.html", .7), ("contact.html", .6),
]

e = html.escape


# =====================================================================
# SMALL HELPERS
# =====================================================================
def img(src, alt, cls="", w=800, h=500, eager=False):
    c = ' class="%s"' % cls if cls else ""
    load = 'fetchpriority="high"' if eager else 'loading="lazy" decoding="async"'
    return '<img src="%s" alt="%s"%s width="%d" height="%d" %s>' % (src, e(alt), c, w, h, load)


def paras(lines):
    return "".join("<p>%s</p>" % e(x) for x in lines)


def arrow_link(href, label="READ MORE", cls="read-more", extra=""):
    return '<a class="%s" href="%s"%s>%s <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>' % (cls, href, extra, label)


def section_head(kicker, title, intro=""):
    p = "<p>%s</p>" % intro if intro else ""
    return '<div class="section-head reveal"><span class="kicker">%s</span><h2>%s</h2>%s</div>' % (kicker, title, p)


def page_hero(title, desc, crumb):
    return ('<section class="page-hero"><div class="container">'
            '<nav aria-label="Breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="index.html">Home</a></li>'
            '<li class="breadcrumb-item active" aria-current="page">%s</li></ol></nav>'
            '<h1>%s</h1><p>%s</p></div></section>' % (crumb, title, desc))


def social_links(cls_wrap="social"):
    return "".join('<a href="%s" target="_blank" rel="noopener noreferrer" aria-label="%s"><i class="%s" aria-hidden="true"></i></a>'
                   % (u, n, ic) for n, ic, u in SOCIAL)


def join_attrs():
    return ' target="_blank" rel="noopener noreferrer"' if JOIN_EXTERNAL else ""


def pillar_details_html():
    out = ""
    for (ic, title, _), d in zip(PILLARS, PILLAR_DETAILS):
        lst = ""
        if d["items"]:
            lst = "<p class=\"fw-semibold mb-1\">%s</p><ul class=\"check-list\">%s</ul>" % (e(d["items_title"]), "".join("<li>%s</li>" % e(i) for i in d["items"]))
        out += ("<article class=\"card-x pillar-detail mb-4 reveal\"><div class=\"card-body-x\"><span class=\"kicker\">%s</span>"
                "<h3><i class=\"fa-solid %s text-warning me-2\" aria-hidden=\"true\"></i>%s</h3>%s%s<p class=\"fw-semibold mb-0\" style=\"color:var(--navy)\">%s</p></div></article>"
                % (d["label"], ic, title, paras(d["paras"]), lst, e(d["closing"])))
    return out


def segments_html():
    return "".join("<div class=\"col-md-6 reveal\"><div class=\"d-flex gap-3\"><span class=\"opp-icon flex-shrink-0\"><i class=\"fa-solid %s\" aria-hidden=\"true\"></i></span>"
                   "<div><h3 class=\"h6 mb-1\"><a href=\"programmes.html#%s\">%d. %s</a></h3><p class=\"text-muted small mb-0\">%s</p></div></div></div>"
                   % (p["icon"], p["slug"], i, e(p["title"]), e(p["short"])) for i, p in enumerate(PROGRAMMES, 1))


# =====================================================================
# SHARED LAYOUT
# =====================================================================
def nav_html():
    prog = "".join('<li><a class="dropdown-item" href="programmes.html#%s">%s</a></li>' % (p["slug"], e(p["title"])) for p in PROGRAMMES)
    comm = "".join('<li><a class="dropdown-item" href="community.html#%s">%s</a></li>' % (a, e(b)) for a, b in
                   [("announcements", "Announcements"), ("events", "Meetings & Events"), ("celebrations", "Celebrations"),
                    ("condolences", "Condolences & Support"), ("gallery", "Photo Gallery")])
    # (labels are HTML-escaped by e(b) above)

    def item(label, href, pages):
        return '<li class="nav-item"><a class="nav-link" href="%s" data-page="%s">%s</a></li>' % (href, pages, label)

    def drop(label, href, pages, menu, all_label):
        return ('<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="%s" data-page="%s" role="button" data-bs-toggle="dropdown" aria-expanded="false">%s</a>'
                '<ul class="dropdown-menu">%s<li><hr class="dropdown-divider"></li><li><a class="dropdown-item fw-semibold" href="%s">%s</a></li></ul></li>'
                % (href, pages, label, menu, href, all_label))

    return ('<ul class="navbar-nav ms-auto align-items-xl-center">' + item("Home", "index.html", "index.html,") +
            item("About Us", "about.html", "about.html") + item("News &amp; Updates", "news.html", "news.html") +
            drop("Our Programmes", "programmes.html", "programmes.html", prog, "All programmes") +
            item("People of Bulamogi", "people.html", "people.html") + item("Opportunities", "opportunities.html", "opportunities.html") +
            drop("Community", "community.html", "community.html", comm, "Community home") +
            item("Contact Us", "contact.html", "contact.html") + '</ul>')


def header_html():
    return ('<div class="topbar"><div class="container d-flex flex-wrap justify-content-between align-items-center gap-1">'
            '<div><span class="welcome">Welcome to Bulamogi Media Community!</span> '
            '<span class="d-none d-lg-inline">Connecting Bulamogi wherever you are.</span></div>'
            '<div class="d-flex flex-wrap align-items-center justify-content-center">'
            '<a class="contact-item" href="mailto:%s"><i class="fa-solid fa-envelope" aria-hidden="true"></i>%s</a>'
            '<a class="contact-item" href="tel:+%s"><i class="fa-solid fa-phone" aria-hidden="true"></i>%s</a>'
            '<span class="social">%s</span></div></div></div>'
            '<header class="site-header"><nav class="navbar navbar-expand-xl" aria-label="Main navigation"><div class="container">'
            '<a class="brand" href="index.html" aria-label="Bulamogi Media Community home">'
            '<img src="assets/images/logo-sm.png" alt="" width="79" height="54">'
            '<span class="brand-text"><span class="brand-name">BULAMOGI MEDIA COMMUNITY</span><span class="brand-slogan">%s</span></span></a>'
            '<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">'
            '<i class="fa-solid fa-bars" aria-hidden="true"></i></button>'
            '<div class="collapse navbar-collapse" id="mainNav">%s'
            '<a class="btn btn-gold btn-join ms-xl-3" href="%s"%s>JOIN OUR COMMUNITY</a></div></div></nav></header>'
            % (CONTACT_EMAIL, CONTACT_EMAIL, WHATSAPP_NUMBER, CONTACT_PHONE, social_links(), SLOGAN, nav_html(), JOIN_URL, join_attrs()))


def footer_html():
    quick = [("Home", "index.html"), ("About Us", "about.html"), ("News & Updates", "news.html"), ("People of Bulamogi", "people.html"),
             ("Opportunities", "opportunities.html"), ("Community", "community.html"), ("Contact Us", "contact.html")]
    q = "".join('<li><a href="%s"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i>%s</a></li>' % (h, e(l)) for l, h in quick)
    p = "".join('<li><a href="programmes.html#%s"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i>%s</a></li>' % (x["slug"], e(x["title"])) for x in PROGRAMMES)
    return ('<footer class="footer"><div class="container"><div class="row g-4">'
            '<div class="col-lg-4"><a href="index.html" aria-label="Bulamogi Media Community home"><img class="footer-logo" src="assets/images/logo.jpg" alt="Bulamogi Media Community official logo" width="260" height="173" loading="lazy"></a>'
            '<p class="slogan-f">%s</p>'
            '<p>A community-based communication platform connecting the people of Bulamogi, here at home and across the world.</p>'
            '<div class="social-big">%s</div></div>'
            '<div class="col-6 col-lg-2"><h3>Quick Links</h3><ul>%s</ul></div>'
            '<div class="col-6 col-lg-3"><h3>Our Programmes</h3><ul>%s</ul></div>'
            '<div class="col-lg-3"><h3>Contact</h3><ul>'
            '<li><i class="fa-solid fa-location-dot text-warning me-2" aria-hidden="true"></i>Bulamogi, Uganda <small>(address to be added)</small></li>'
            '<li><i class="fa-solid fa-envelope text-warning me-2" aria-hidden="true"></i><a href="mailto:%s">%s</a></li>'
            '<li><i class="fa-solid fa-phone text-warning me-2" aria-hidden="true"></i><a href="tel:+%s">%s</a></li>'
            '<li><i class="fa-brands fa-whatsapp text-warning me-2" aria-hidden="true"></i><a href="%s" target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></li>'
            '</ul><p class="small mt-2 mb-0">The email address and physical address are placeholders until the official details are added.</p></div>'
            '</div><div class="footer-bottom d-flex flex-wrap justify-content-between gap-2"><span>&copy; 2026 Bulamogi Media Community. All rights reserved.</span>'
            '<span>%s</span></div></div></footer>'
            % (SLOGAN, social_links(), q, p, CONTACT_EMAIL, CONTACT_EMAIL, WHATSAPP_NUMBER, CONTACT_PHONE, WA_LINK, TAGLINE))


def page(fname, title, desc, body, scripts=(), extra_head=""):
    full_title = title if fname == "index.html" else "%s | %s" % (title, SITE_NAME)
    url = "%s/%s" % (SITE_URL, "" if fname == "index.html" else fname)
    og_img = SITE_URL + "/assets/images/og-image.jpg"
    js = "".join('<script src="assets/js/%s"></script>' % s for s in scripts)
    return """<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%(title)s</title>
<meta name="description" content="%(desc)s">
<meta name="theme-color" content="#102A43">
<link rel="canonical" href="%(url)s">
<link rel="icon" type="image/png" sizes="64x64" href="assets/icons/favicon.png">
<link rel="icon" type="image/png" sizes="192x192" href="assets/icons/favicon-192.png">
<link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">
<meta property="og:type" content="website">
<meta property="og:site_name" content="%(site)s">
<meta property="og:title" content="%(title)s">
<meta property="og:description" content="%(desc)s">
<meta property="og:url" content="%(url)s">
<meta property="og:image" content="%(og)s">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Bulamogi Media Community official logo">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="%(title)s">
<meta name="twitter:description" content="%(desc)s">
<meta name="twitter:image" content="%(og)s">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">
%(extra)s</head>
<body>
<a class="skip-link" href="#main">Skip to main content</a>
%(header)s
<main id="main">
%(body)s
</main>
%(footer)s
<button class="to-top" id="toTop" type="button" aria-label="Back to top"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
%(js)s
</body>
</html>
""" % dict(title=e(full_title), desc=e(desc), url=url, site=SITE_NAME, og=og_img, extra=extra_head,
           header=header_html(), body=body, footer=footer_html(), js=js)


# =====================================================================
# REUSABLE COMPONENT BUILDERS
# =====================================================================
def news_card(n, detail=False):
    """detail=True: used on news.html (opens modal). detail=False: link to news.html#id."""
    href = "#%s" % n["id"] if detail else "news.html#%s" % n["id"]
    alt = "Illustration for news story: %s" % n["title"]
    cat_link = "news.html?cat=%s" % urllib.parse.quote(n["cat"])
    wrap_open = ('<div class="col-md-6 col-lg-4 js-item detail-card" id="%s" data-category="%s" data-text="%s">'
                 % (n["id"], e(n["cat"]), e((n["title"] + " " + n["excerpt"] + " " + n["cat"]).lower())))
    meta = '<i class="fa-regular fa-calendar" aria-hidden="true"></i> %s &middot; %s' % (n["date"], e(n["cat"]))
    body = paras(n["body"]) + '<p><span class="demo-badge">Demonstration content</span></p>'
    return (wrap_open + '<article class="card-x"><div class="thumb"><span class="cat-label">%s</span>%s</div>'
            '<div class="card-body-x"><div class="meta">%s</div><h3 class="detail-title">%s</h3><p>%s</p>'
            '<div class="push">%s</div></div><div class="detail-body d-none">%s</div><div class="detail-meta-src d-none">%s</div></article></div>'
            % (e(n["cat"]), img("assets/images/news/%s.svg" % n["id"], alt), meta, e(n["title"]), e(n["excerpt"]),
               arrow_link(href).replace('class="read-more"', 'class="read-more js-detail"'), body, meta)
            )


def programme_card(p):
    return ('<div class="col-md-6 col-lg-4 reveal"><article class="card-x"><div class="thumb">%s<span class="prog-icon"><i class="fa-solid %s" aria-hidden="true"></i></span></div>'
            '<div class="card-body-x"><h3>%s</h3><p>%s</p><div class="push">%s</div></div></article></div>'
            % (img("assets/images/programmes/%s.svg" % p["slug"], "Illustration for the programme %s" % p["title"]), p["icon"], e(p["title"]), e(p["short"]),
               arrow_link("programmes.html#%s" % p["slug"])))


def people_card(p, detail=False):
    href = "#%s" % p["id"] if detail else "people.html#%s" % p["id"]
    link = arrow_link(href, "VIEW PROFILE")
    if detail:
        link = link.replace('class="read-more"', 'class="read-more js-detail"')
    attrs = (' js-item detail-card" id="%s" data-category="%s" data-text="%s' % (p["id"], e(p["role"]), e((p["headline"] + " " + p["short"] + " " + p["role"]).lower()))) if detail else " reveal"
    body = ('<div class="detail-body d-none">%s<p><span class="demo-badge">Demonstration profile</span></p></div>'
            '<div class="detail-meta-src d-none">%s</div>' % (paras(p["body"]), e(p["role"]))) if detail else ""
    return ('<div class="col-md-6 col-lg-4%s"><article class="card-x profile-card"><div class="avatar">%s</div>'
            '<div class="card-body-x"><span class="role">%s</span><h3 class="detail-title">%s</h3>'
            '<p class="mb-1 fw-semibold small text-muted">Name to be added</p><p>%s</p><div class="push">%s</div></div>%s</article></div>'
            % (attrs, img("assets/images/people/%s.svg" % p["id"], "Placeholder portrait for the demonstration profile: %s" % p["headline"], w=400, h=400),
               e(p["role"]), e(p["headline"]), e(p["short"]), link, body))


def opp_card(o, detail=False):
    href = "#%s" % o["id"] if detail else "opportunities.html#%s" % o["id"]
    dl = ('<div class="deadline"><i class="fa-regular fa-clock" aria-hidden="true"></i>Sample deadline: %s</div>' % o["deadline"]) if o["deadline"] else \
         '<div class="deadline text-muted"><i class="fa-regular fa-clock" aria-hidden="true"></i>Open / no fixed deadline</div>'
    apply_ = ('<a class="btn btn-navy btn-sm-x" href="%s" target="_blank" rel="noopener noreferrer">%s <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i></a>' % (o["link"], e(o["link_label"]))
              if o["link"] else '<a class="btn btn-outline-navy btn-sm-x" href="contact.html">Ask us how to apply</a>')
    more = arrow_link(href, "DETAILS")
    if detail:
        more = more.replace('class="read-more"', 'class="read-more js-detail"')
    attrs = (' js-item detail-card" id="%s" data-category="%s" data-text="%s' % (o["id"], e(o["cat"]), e((o["title"] + " " + o["desc"] + " " + o["cat"]).lower()))) if detail else " reveal"
    body = ('<div class="detail-body d-none">%s%s<p>%s</p></div><div class="detail-meta-src d-none">%s &middot; %s</div>'
            % (paras(o["body"]), '<p><strong>Sample deadline:</strong> %s</p>' % o["deadline"] if o["deadline"] else "", apply_, e(o["cat"]), "Demonstration listing")) if detail else ""
    return ('<div class="col-md-6 col-lg-4%s"><article class="card-x opp-card"><div class="card-body-x">'
            '<div class="d-flex justify-content-between align-items-start"><span class="opp-icon"><i class="fa-solid %s" aria-hidden="true"></i></span><span class="demo-badge">%s</span></div>'
            '<h3 class="detail-title">%s</h3><p>%s</p>%s<div class="push d-flex flex-wrap align-items-center gap-3">%s%s</div></div>%s</article></div>'
            % (attrs, o["icon"], e(o["cat"]), e(o["title"]), e(o["desc"]), dl, apply_, more, body))


def newsletter_section():
    badge = "" if NEWSLETTER_ENDPOINT else '<span class="demo-badge mb-2">Demonstration form &ndash; not connected</span>'
    ep = ' data-endpoint="%s"' % NEWSLETTER_ENDPOINT if NEWSLETTER_ENDPOINT else ""
    return ('<section class="pb-5" aria-labelledby="nl-title"><div class="container"><div class="newsletter reveal"><div class="row align-items-center g-4">'
            '<div class="col-lg-5"><span class="kicker">Stay connected</span>%s<h2 id="nl-title">Get Bulamogi news in your inbox</h2>'
            '<p class="text-muted mb-0">A short, friendly round-up of news, opportunities and community notices.</p></div>'
            '<div class="col-lg-7"><form class="js-form" novalidate%s><input type="text" name="_gotcha" class="d-none" tabindex="-1" autocomplete="off" aria-hidden="true">'
            '<div class="row g-2"><div class="col-md-5"><label class="visually-hidden" for="nl-name">Your name</label><input class="form-control" id="nl-name" name="name" placeholder="Your name" required autocomplete="name"><div class="invalid-feedback">Please enter your name.</div></div>'
            '<div class="col-md-5"><label class="visually-hidden" for="nl-email">Email address</label><input class="form-control" id="nl-email" type="email" name="email" placeholder="Email address" required autocomplete="email"><div class="invalid-feedback">Enter a valid email address.</div></div>'
            '<div class="col-md-2 d-grid"><button class="btn btn-gold" type="submit">Subscribe</button></div></div>'
            '<div class="form-status" aria-live="polite"></div></form></div></div></div></div></section>' % (badge, ep))


def cta_section():
    return ('<section class="cta"><div class="container reveal"><span class="kicker" style="color:var(--gold)">Join the family</span>'
            '<h2>BULAMOGI IS OUR HOME. <span>OUR UNITY IS OUR STRENGTH.</span></h2>'
            '<p>Whether you are at home or abroad, you are part of this family. Let us connect, share, support and build our community together.</p>'
            '<a class="btn btn-gold btn-lg" href="%s"%s><i class="fa-brands fa-whatsapp me-2" aria-hidden="true"></i>JOIN OUR COMMUNITY</a></div></section>' % (JOIN_URL, join_attrs()))


# ---------------------------------------------------------------- world map
def project(lon, lat):
    return (lon + 180) / 360 * 1000, (90 - lat) / 180 * 500


CONTINENTS = [
    [(-168, 66), (-140, 70), (-95, 72), (-80, 70), (-62, 55), (-55, 47), (-70, 42), (-76, 35), (-81, 25), (-90, 29), (-97, 26), (-105, 20), (-92, 15), (-83, 9), (-80, 8), (-100, 18), (-117, 32), (-125, 42), (-130, 55)],
    [(-80, 9), (-62, 10), (-50, 0), (-35, -6), (-40, -22), (-48, -27), (-58, -38), (-65, -55), (-73, -50), (-72, -30), (-70, -18), (-81, -5)],
    [(-10, 36), (-9, 43), (-2, 48), (3, 51), (8, 57), (5, 62), (15, 69), (30, 70), (40, 66), (40, 55), (30, 45), (27, 40), (15, 38), (5, 37)],
    [(-17, 21), (-10, 35), (10, 37), (32, 31), (35, 28), (43, 12), (51, 12), (40, -5), (40, -15), (33, -27), (20, -35), (15, -28), (12, -5), (9, 4), (-8, 4), (-17, 14)],
    [(40, 55), (40, 66), (60, 70), (100, 77), (140, 72), (170, 66), (160, 55), (140, 45), (122, 30), (122, 22), (108, 10), (100, 2), (98, 16), (90, 22), (80, 8), (72, 20), (60, 25), (50, 28), (35, 35), (30, 45)],
    [(114, -22), (130, -12), (142, -11), (153, -26), (147, -38), (135, -35), (115, -34)],
]
LOCATIONS = [  # name, lon, lat, label side
    ("Bulamogi, Uganda", 33.4, 1.0, "r"), ("London", -0.1, 51.5, "r"), ("Dubai", 55.3, 25.2, "r"),
    ("Johannesburg", 28.0, -26.2, "r"), ("Toronto", -79.4, 43.7, "r"), ("Guangzhou", 113.3, 23.1, "r"), ("Sydney", 151.2, -33.9, "l"),
]


def world_map():
    polys = "".join('<polygon points="%s" fill="url(#dots)" stroke="rgba(255,255,255,.15)" stroke-width="1"/>'
                    % " ".join("%.1f,%.1f" % project(*pt) for pt in poly) for poly in CONTINENTS)
    pins = ""
    for name, lon, lat, side in LOCATIONS:
        x, y = project(lon, lat)
        home = name.startswith("Bulamogi")
        col = "#E0A526" if home else "#ffffff"
        tx, anchor = (x + 11, "start") if side == "r" else (x - 11, "end")
        pins += ('<g><circle class="pin-pulse" cx="%.1f" cy="%.1f" r="5" fill="%s" opacity=".8"/><circle cx="%.1f" cy="%.1f" r="%d" fill="%s"/>'
                 '<text x="%.1f" y="%.1f" text-anchor="%s" fill="%s" font-size="%d" font-family="Poppins,Arial,sans-serif" font-weight="600">%s</text></g>'
                 % (x, y, col, x, y, 5 if home else 4, col, tx, y + 4, anchor, col, 15 if home else 13, e(name)))
    return ('<svg viewBox="0 0 1000 500" role="img" aria-label="World map illustration with Bulamogi at the centre and locations where Bulamogi people live. Locations are illustrative.">'
            '<defs><pattern id="dots" width="9" height="9" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.7" fill="#7fb3e0"/></pattern></defs>%s%s</svg>' % (polys, pins))


# =====================================================================
# PAGES
# =====================================================================
def build_home():
    ticker = "".join('<a href="%s">%s</a>' % (h, e(t)) for t, h in TICKER)
    prog = "".join(programme_card(p) for p in PROGRAMMES)
    pillars = "".join('<div class="col-md-4 reveal d%d"><div class="pillar"><span class="num">0%d</span><div class="icon"><i class="fa-solid %s" aria-hidden="true"></i></div><h3>%s</h3><p>%s</p></div></div>'
                      % (i, i, ic, t, d) for i, (ic, t, d) in enumerate(PILLARS, 1))
    n = {x["id"]: x for x in NEWS}
    f = n["n1"]
    featured = ('<article class="news-featured">%s<div class="overlay"><span class="cat-label" style="position:static;display:inline-block;margin-bottom:.8rem">%s</span>'
                '<div class="meta" style="color:#cbd8e6"><i class="fa-regular fa-calendar" aria-hidden="true"></i> %s &middot; Demonstration content</div>'
                '<h3>%s</h3><p>%s</p>%s</div></article>'
                % (img("assets/images/news/n1.svg", "Illustration for news story: " + f["title"], eager=False), e(f["cat"]), f["date"], e(f["title"]), e(f["excerpt"]), arrow_link("news.html#n1")))
    rows = ""
    for k in ("n2", "n3", "n4", "n5"):
        x = n[k]
        rows += ('<div class="news-row">%s<div><a class="tag" href="news.html?cat=%s">%s</a><h4>%s</h4><div class="meta mb-1"><i class="fa-regular fa-calendar" aria-hidden="true"></i> %s</div>%s</div></div>'
                 % (img("assets/images/news/%s.svg" % k, "Illustration for news story: " + x["title"], w=110, h=90), urllib.parse.quote(x["cat"]), e(x["cat"]), e(x["title"]), x["date"], arrow_link("news.html#" + k)))
    cat_chips = "".join('<a class="chip" href="news.html?cat=%s">%s</a>' % (urllib.parse.quote(c), e(c)) for c in NEWS_CATS)
    people = "".join(people_card(p) for p in PEOPLE)
    opps = "".join(opp_card(o) for o in OPPS if o["id"] in ("o1", "o3", "o5", "o6", "o7", "o8"))
    tiles = [("fa-cake-candles", "Birthdays", "Warm wishes for every age"), ("fa-ring", "Weddings", "Love and new beginnings"),
             ("fa-graduation-cap", "Graduations", "Hard work rewarded"), ("fa-heart", "Anniversaries", "Years of commitment"),
             ("fa-baby", "Birth Announcements", "Welcome, little one"), ("fa-trophy", "Promotions & Achievements", "Success worth sharing")]
    tile_html = "".join('<div class="col-6 col-md-4 reveal"><a class="tile" href="community.html#celebrations"><i class="fa-solid %s" aria-hidden="true"></i><h3>%s</h3><small>%s</small></a></div>' % t for t in tiles)
    slides = [("c2", "Share your good news", "Birthdays, weddings and family milestones, celebrated together."),
              ("c3", "Congratulations, graduates", "Every certificate is a victory for a whole family."),
              ("c6", "Your joy is our joy", "Send your announcement and let the community celebrate with you.")]
    car_items = "".join('<div class="carousel-item%s">%s<div class="carousel-caption"><h3>%s</h3><p class="mb-0">%s</p></div></div>'
                        % (" active" if i == 0 else "", img("assets/images/community/%s.svg" % c, "Illustration: " + t), t, d) for i, (c, t, d) in enumerate(slides))
    carousel = ('<div id="celebCarousel" class="carousel slide carousel-x" data-bs-ride="carousel" aria-label="Featured celebrations"><div class="carousel-inner">%s</div>'
                '<button class="carousel-control-prev" type="button" data-bs-target="#celebCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="visually-hidden">Previous</span></button>'
                '<button class="carousel-control-next" type="button" data-bs-target="#celebCarousel" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span></button></div>' % car_items)
    solemn = [("fa-dove", "Condolence Messages", "Words of comfort from the whole community for grieving families."),
              ("fa-scroll", "Bereavement Announcements", "Notices shared respectfully and only with the family's consent."),
              ("fa-triangle-exclamation", "Emergency Updates", "Clear, calm information when the community needs it most."),
              ("fa-hand-holding-heart", "Community Support Initiatives", "Practical help organised openly and with care.")]
    solemn_html = "".join('<div class="col-sm-6 col-lg-3 reveal"><div class="solemn-card"><i class="fa-solid %s" aria-hidden="true"></i><h3>%s</h3><p>%s</p></div></div>' % s for s in solemn)
    loc_list = "".join('<li><i class="fa-solid fa-location-dot" aria-hidden="true"></i>%s</li>' % e(l[0]) for l in LOCATIONS)
    jsonld = ('<script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"%s","slogan":"One Community. One Voice. One Family.","url":"%s/","logo":"%s/assets/images/logo.png"}</script>\n' % (SITE_NAME, SITE_URL, SITE_URL))

    body = f"""
<section class="hero" id="home" aria-labelledby="hero-title">
  <img class="hero-img" src="assets/images/hero.svg" alt="" width="1600" height="900" fetchpriority="high">
  <div class="container">
    <div class="row align-items-center"><div class="col-lg-7">
      <span class="eyebrow">WELCOME TO</span>
      <h1 id="hero-title">BULAMOGI MEDIA COMMUNITY</h1>
      <p class="slogan">{SLOGAN}</p>
      <p class="tagline">{TAGLINE}</p>
      <p class="lead-text">&ldquo;Your community, your people, your voice. Connecting Bulamogi wherever you are.&rdquo;</p>
      <a class="btn btn-gold btn-lg me-2 mb-2" href="community.html">EXPLORE OUR COMMUNITY</a>
      <a class="btn btn-outline-light-x btn-lg mb-2" href="about.html">ABOUT US</a>
    </div>
    <div class="col-lg-5 d-none d-lg-block text-center"><img class="hero-logo" src="assets/images/logo.jpg" alt="Bulamogi Media Community official logo" width="480" height="320" fetchpriority="high"></div></div>
  </div>
  <div class="hero-wave" aria-hidden="true"><svg viewBox="0 0 1440 60" preserveAspectRatio="none" width="100%" height="50"><path d="M0 60V30C240 0 480 0 720 25s480 30 720 5v30z" fill="#fff"/></svg></div>
</section>

<section class="ticker" aria-label="Latest updates">
  <div class="ticker-label"><span class="dot" aria-hidden="true"></span><span class="txt">LATEST&nbsp;</span>UPDATES</div>
  <div class="ticker-track"><div class="ticker-move">{ticker}</div></div>
</section>

<section class="section" id="about-us" aria-labelledby="about-title">
  <div class="container"><div class="row align-items-center g-5">
    <div class="col-lg-6 reveal"><div class="about-img">{img("assets/images/programmes/our-community-our-responsibility.svg", "Illustration of people standing together as one community", 800, 500)}</div></div>
    <div class="col-lg-6 reveal d1">
      <span class="kicker">About our community</span>
      <h2 id="about-title">A bridge between people, a voice for our community</h2>
      <p>Bulamogi Community Media is a community-based communication platform established to bring the people of Bulamogi together, keep them informed and strengthen the spirit of unity, belonging and togetherness.</p>
      <p>Whether you are in Bulamogi, elsewhere in Uganda or living abroad, you remain an important part of our community.</p>
      <div class="counter-row">
        <div class="counter"><div class="num"><span class="count" data-count="7">7</span></div><small>Regular programmes</small></div>
        <div class="counter"><div class="num"><span class="count" data-count="3">3</span></div><small>Core pillars</small></div>
        <div class="counter"><div class="num"><span class="count" data-count="8">8</span></div><small>Core values</small></div>
        <div class="counter"><div class="num"><span class="count" data-count="1">1</span></div><small>Family</small></div>
      </div>
      <a class="btn btn-navy" href="about.html">READ MORE</a>
    </div>
  </div></div>
</section>

<section class="section section-grey" aria-labelledby="pillars-title">
  <div class="container">
    {section_head("What we stand for", '<span id="pillars-title">Our Three Core Pillars</span>')}
    <div class="row g-4">{pillars}</div>
  </div>
</section>

<section class="section" aria-labelledby="prog-title">
  <div class="container">
    {section_head("What we do", '<span id="prog-title">Our Regular Programmes</span>', "Seven programmes that connect, inform, celebrate and support the people of Bulamogi.")}
    <div class="row g-4">{prog}</div>
    <div class="text-center mt-5"><a class="btn btn-outline-navy" href="programmes.html">VIEW ALL PROGRAMMES</a></div>
  </div>
</section>

<section class="section section-grey" aria-labelledby="news-title">
  <div class="container">
    {section_head("Stay informed", '<span id="news-title">Latest News and Updates</span>', "Local, national and international news that matters to Bulamogi. Stories shown here are demonstration content.")}
    <div class="row g-4">
      <div class="col-lg-7 reveal">{featured}</div>
      <div class="col-lg-5 reveal d1">{rows}</div>
    </div>
    <div class="chips justify-content-center mt-4" aria-label="Browse news by category">{cat_chips}</div>
    <div class="text-center mt-4"><a class="btn btn-navy" href="news.html">VIEW ALL NEWS</a></div>
  </div>
</section>

<section class="section" aria-labelledby="people-title">
  <div class="container">
    {section_head("Celebrating our own", '<span id="people-title">People of Bulamogi</span>', "Outstanding individuals, entrepreneurs, professionals, leaders, students and volunteers. Profiles shown are demonstration placeholders.")}
    <div class="row g-4">{people}</div>
    <div class="text-center mt-5"><a class="btn btn-outline-navy" href="people.html">MEET MORE PEOPLE</a></div>
  </div>
</section>

<section class="section section-grey" aria-labelledby="opp-title">
  <div class="container">
    {section_head("Opportunities Corner", '<span id="opp-title">Opportunities for Our People</span>', "Employment, scholarships, business, training, tenders and government programmes. Listings are demonstration samples.")}
    <div class="row g-4">{opps}</div>
    <div class="text-center mt-5"><a class="btn btn-navy" href="opportunities.html">BROWSE ALL OPPORTUNITIES</a></div>
  </div>
</section>

<section class="section" aria-labelledby="celeb-title">
  <div class="container">
    {section_head("Celebrating With You", '<span id="celeb-title">Your Joy Is Our Joy</span>', "Birthdays, weddings, graduations, anniversaries, new babies and achievements: share them with the family.")}
    <div class="row g-4 align-items-center">
      <div class="col-lg-6 reveal">{carousel}</div>
      <div class="col-lg-6"><div class="row g-3">{tile_html}</div></div>
    </div>
  </div>
</section>

<section class="section solemn" aria-labelledby="diff-title">
  <div class="container">
    {section_head("Together in Difficult Times", '<span id="diff-title">We Stand With You</span>', "A true community stands together not only during good times but also when life becomes difficult.")}
    <div class="row g-4">{solemn_html}</div>
    <p class="solemn-quote">&ldquo;Our strength lies in our unity, compassion and willingness to support one another.&rdquo;</p>
    <div class="text-center mt-3"><a class="btn btn-outline-navy" href="community.html#condolences">VIEW SUPPORT &amp; CONDOLENCES</a></div>
  </div>
</section>

<section class="section section-navy" aria-labelledby="world-title">
  <div class="container">
    {section_head("Bulamogi Worldwide", '<span id="world-title">One Family, Every Continent</span>', "Distance should never separate us, and our differences should never divide us. Bulamogi people stay connected across Uganda and the world. Locations shown are illustrative.")}
    <div class="row g-4 align-items-center">
      <div class="col-lg-8 reveal"><div class="map-wrap">{world_map()}</div></div>
      <div class="col-lg-4 reveal d1"><ul class="loc-list">{loc_list}</ul>
        <a class="btn btn-gold mt-4" href="programmes.html#bulamogi-worldwide">ABOUT BULAMOGI WORLDWIDE</a></div>
    </div>
  </div>
</section>

{cta_section()}
<div style="height:4rem" aria-hidden="true"></div>
{newsletter_section()}
"""
    return page("index.html", "Bulamogi Media Community | One Community. One Voice. One Family.",
                "Bulamogi Media Community connects, informs and unites the people of Bulamogi in Uganda and across the world with news, programmes, opportunities and community support.",
                body, extra_head=jsonld)


def build_about():
    pillars = "".join('<div class="col-md-4 reveal d%d"><div class="pillar"><span class="num">0%d</span><div class="icon"><i class="fa-solid %s" aria-hidden="true"></i></div><h3>%s</h3><p>%s</p></div></div>'
                      % (i, i, ic, t, d) for i, (ic, t, d) in enumerate(PILLARS, 1))
    values = "".join('<div class="col-sm-6 col-lg-3 reveal"><div class="value-card"><i class="fa-solid %s" aria-hidden="true"></i><h3>%s</h3><p>%s</p></div></div>' % v for v in VALUES)
    pillar_details = pillar_details_html()
    segments = segments_html()
    body = page_hero("About Us", "A community-based communication platform for the people of Bulamogi, at home and across the world.", "About Us") + f"""
<section class="section" aria-labelledby="intro-title"><div class="container"><div class="row g-5 align-items-center">
  <div class="col-lg-6 reveal"><span class="kicker">Introduction</span><h2 id="intro-title">Who we are</h2>
    <p>Bulamogi Community Media is a community-based communication platform established to bring the people of Bulamogi together, keep them informed and strengthen the spirit of unity, belonging and togetherness.</p>
    <p>We believe that a community is more than just a place where people come from. It is about shared identity, common values, relationships and the responsibility we have towards one another.</p>
    <p>Whether you are in Bulamogi, elsewhere in Uganda or living abroad, you remain an important part of our community.</p>
    <p>Our mission is to build a platform that connects people across geographical boundaries, shares reliable and timely information, celebrates achievements, promotes opportunities and provides a supportive voice during challenging times.</p></div>
  <div class="col-lg-6 reveal d1"><div class="about-img">{img("assets/images/news/n1.svg", "Illustration of community members gathered together")}</div></div>
</div></div></section>

<section class="section section-grey" aria-labelledby="identity-title"><div class="container"><div class="row g-4">
  <div class="col-lg-6 reveal"><span class="kicker">Identity and purpose</span><h2 id="identity-title">A shared identity, a shared purpose</h2>
    <p>Our identity is built on belonging. The Bulamogi Media Community logo brings together a cheering crowd (our people), the map of Bulamogi with its lake and a handshake (home and unity), and a broadcast tower, video camera and laptop (media and connection), all beneath our slogan.</p>
    <p>Our purpose is simple: to make sure that no member of the Bulamogi family is left uninformed, unrecognised or unsupported, wherever they live.</p></div>
  <div class="col-lg-6 reveal d1 text-center"><img class="about-logo mb-4" src="assets/images/logo.png" alt="Bulamogi Media Community official logo" width="640" height="438" loading="lazy"><div class="quote-band text-start">ONE COMMUNITY. ONE VOICE. ONE FAMILY.<br><small class="fw-normal text-muted">{TAGLINE}</small></div></div>
</div></div></section>

<section class="section" aria-label="Vision and mission"><div class="container"><div class="row g-4">
  <div class="col-md-6 reveal"><div class="vm-card vision"><i class="fa-solid fa-binoculars bg" aria-hidden="true"></i><span class="kicker">Our Vision</span><h2>Vision</h2>
    <p class="mb-0">To become a trusted and unifying community media platform that connects the people of Bulamogi worldwide, promotes access to information and inspires collective growth, development and social responsibility.</p></div></div>
  <div class="col-md-6 reveal d1"><div class="vm-card mission"><i class="fa-solid fa-bullseye bg" aria-hidden="true"></i><span class="kicker">Our Mission</span><h2>Mission</h2>
    <p class="mb-0">To connect, inform, inspire and unite the people of Bulamogi through responsible communication, timely information sharing, community engagement and mutual support.</p></div></div>
</div></div></section>

<section class="section section-grey" aria-labelledby="pillars-title"><div class="container">
  {section_head("What we stand for", '<span id="pillars-title">Our Three Core Pillars</span>')}<div class="row g-4">{pillars}</div><div class="mt-5">{pillar_details}</div></div></section>

<section class="section" aria-labelledby="seg-title"><div class="container">
  {section_head("What we do", '<span id="seg-title">Our Regular Programmes and Community Segments</span>')}<div class="row g-4">{segments}</div>
  <div class="text-center mt-4"><a class="btn btn-outline-navy" href="programmes.html">SEE ALL PROGRAMMES</a></div></div></section>

<section class="section section-grey" aria-labelledby="values-title"><div class="container">
  {section_head("What guides us", '<span id="values-title">Our Core Values</span>')}<div class="row g-3 g-md-4">{values}</div></div></section>

<section class="section" aria-labelledby="commit-title"><div class="container"><div class="row justify-content-center"><div class="col-lg-9 reveal">
  <span class="kicker">Our Commitment</span><h2 id="commit-title">More than a media platform</h2>
  <p>Bulamogi Community Media is more than just a media platform. It is a bridge between people, a voice for our community and a home for information, connection and togetherness.</p>
  <p>We are committed to creating a respectful and welcoming environment where people can share ideas, access information, celebrate achievements, discuss important issues and contribute positively to the future of Bulamogi.</p>
  <p>We encourage constructive conversations, discourage misinformation, personal attacks and divisive discussions, and promote the interests of our community above individual differences.</p>
  <a class="btn btn-gold" href="contact.html">GET IN TOUCH</a>
</div></div></div></section>
{cta_section()}
"""
    return page("about.html", "About Us", "Learn about Bulamogi Media Community: our identity, vision, mission, three core pillars, core values and commitment to the people of Bulamogi.", body)


def build_news():
    cards = "".join(news_card(n, detail=True) for n in NEWS)
    chips = '<button type="button" class="chip active" data-filter="all" aria-pressed="true">All</button>' + "".join(
        '<button type="button" class="chip" data-filter="%s" aria-pressed="false">%s</button>' % (e(c), e(c)) for c in NEWS_CATS)
    body = page_hero("News & Updates", "Reliable and timely news from Bulamogi, Uganda and the world.", "News &amp; Updates") + f"""
<section class="pb-5"><div class="container js-filter-root" id="newsRoot" data-noun="article">
  <div class="toolbar">
    <form role="search" class="search-box" aria-label="Search news"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
      <label class="visually-hidden" for="newsSearch">Search news</label>
      <input class="form-control js-search" id="newsSearch" type="search" placeholder="Search news by keyword..."></form>
    <div class="chips" role="group" aria-label="Filter by category">{chips}</div>
  </div>
  <div class="quote-band mt-4">We shall promote accuracy, fairness, responsible reporting and timely information sharing.<br><small class="fw-normal text-muted">We share local community news, national and international news, education, health and business updates, government programmes, opportunities and important community events.</small></div><p class="demo-note mt-3 mb-0"><i class="fa-solid fa-circle-info me-2" aria-hidden="true"></i>All stories on this page are <strong>demonstration content</strong> to show the layout. Replace them with real reporting.</p>
  <div class="d-flex justify-content-between align-items-center"><p class="result-count js-count" aria-live="polite"></p>
    <button type="button" class="btn btn-sm-x btn-outline-navy" id="clearFilters">Clear filters</button></div>
  <div class="row g-4">{cards}</div>
  <div class="js-empty empty-state" hidden><i class="fa-regular fa-face-frown" aria-hidden="true"></i><h2 class="h5">No stories match your search</h2><p>Try a different word or clear the filters.</p></div>
</div></section>
{newsletter_section()}
"""
    return page("news.html", "News & Updates", "Local, national and international news, education, health, business and community development updates for the people of Bulamogi. Search and filter by category.",
                body, scripts=("search.js", "news.js"))


def build_programmes():
    blocks = ""
    for i, p in enumerate(PROGRAMMES, 1):
        order = " order-lg-2" if i % 2 == 0 else ""
        lis = "".join("<li>%s</li>" % e(b) for b in p["bullets"])
        blocks += (f'<section class="prog-detail" id="{p["slug"]}" aria-labelledby="h-{p["slug"]}"><div class="container"><div class="row g-5 align-items-center">'
                   f'<div class="col-lg-6{order} reveal">{img("assets/images/programmes/%s.svg" % p["slug"], "Illustration for the programme " + p["title"])}</div>'
                   f'<div class="col-lg-6 reveal d1"><span class="num-tag">PROGRAMME 0{i}</span><h2 id="h-{p["slug"]}"><i class="fa-solid {p["icon"]} text-warning me-2" aria-hidden="true"></i>{e(p["title"])}</h2>'
                   f'<p class="fw-semibold">{e(p["short"])}</p><p>{e(p["long"])}</p><ul>{lis}</ul>'
                   f'<a class="btn btn-navy btn-sm-x" href="contact.html">Share a story or suggestion</a></div></div></div></section>')
    body = page_hero("Our Programmes", "Seven regular programmes that connect, inform, celebrate and support the people of Bulamogi.", "Our Programmes") + blocks + cta_section()
    return page("programmes.html", "Our Programmes", "Explore the seven regular programmes of Bulamogi Media Community: Bulamogi Today, People of Bulamogi, Celebrating With You, Opportunities Corner and more.", body)


def build_people():
    cards = "".join(people_card(p, detail=True) for p in PEOPLE)
    chips = '<button type="button" class="chip active" data-filter="all" aria-pressed="true">All</button>' + "".join(
        '<button type="button" class="chip" data-filter="%s" aria-pressed="false">%s</button>' % (e(r), e(r)) for r in PEOPLE_ROLES)
    body = page_hero("People of Bulamogi", "Celebrating outstanding individuals and community contributors.", "People of Bulamogi") + f"""
<section class="pb-5"><div class="container js-filter-root" data-noun="profile">
  <div class="toolbar"><form role="search" class="search-box" aria-label="Search profiles"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
    <label class="visually-hidden" for="peopleSearch">Search profiles</label><input class="form-control js-search" id="peopleSearch" type="search" placeholder="Search profiles..."></form>
    <div class="chips" role="group" aria-label="Filter by role">{chips}</div></div>
  <p class="demo-note mt-4 mb-0"><i class="fa-solid fa-circle-info me-2" aria-hidden="true"></i>These are <strong>demonstration profiles</strong> with placeholder portraits. No real person is shown. Real profiles are published only with the person's permission.</p>
  <p class="result-count js-count" aria-live="polite"></p>
  <div class="row g-4">{cards}</div>
  <div class="js-empty empty-state" hidden><i class="fa-regular fa-face-frown" aria-hidden="true"></i><h2 class="h5">No profiles match your search</h2></div>
</div></section>
<section class="section section-grey"><div class="container text-center reveal"><span class="kicker">Nominate someone</span><h2>Know someone who inspires the community?</h2>
  <p class="text-muted mx-auto" style="max-width:600px">Tell us about an entrepreneur, professional, leader, student or volunteer who deserves to be celebrated.</p>
  <a class="btn btn-gold" href="contact.html">NOMINATE A PERSON</a></div></section>
"""
    return page("people.html", "People of Bulamogi", "Celebrating entrepreneurs, professionals, community leaders, students and volunteers who are making a difference in Bulamogi.", body, scripts=("search.js",))


def build_opps():
    cards = "".join(opp_card(o, detail=True) for o in OPPS)
    chips = '<button type="button" class="chip active" data-filter="all" aria-pressed="true">All</button>' + "".join(
        '<button type="button" class="chip" data-filter="%s" aria-pressed="false">%s</button>' % (c, c) for c in OPP_CATS)
    body = page_hero("Opportunities Corner", "Jobs, scholarships, business, training, tenders and government programmes.", "Opportunities") + f"""
<section class="pb-5"><div class="container js-filter-root" data-noun="opportunity" data-noun-plural="opportunities" id="oppRoot">
  <div class="toolbar"><form role="search" class="search-box" aria-label="Search opportunities"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
    <label class="visually-hidden" for="oppSearch">Search opportunities</label><input class="form-control js-search" id="oppSearch" type="search" placeholder="Search opportunities..."></form>
    <div class="chips" role="group" aria-label="Filter by type">{chips}</div></div>
  <p class="demo-note mt-4 mb-0"><i class="fa-solid fa-circle-info me-2" aria-hidden="true"></i>Listings and deadlines are <strong>demonstration samples</strong>. Links go to official portals only. Always verify opportunities directly with the provider, and never pay money to apply.</p>
  <p class="result-count js-count" aria-live="polite"></p>
  <div class="row g-4">{cards}</div>
  <div class="js-empty empty-state" hidden><i class="fa-regular fa-face-frown" aria-hidden="true"></i><h2 class="h5">No opportunities match your search</h2></div>
</div></section>
<section class="section section-grey"><div class="container text-center reveal"><span class="kicker">Have an opportunity to share?</span><h2>Help someone find their next step</h2>
  <a class="btn btn-gold mt-2" href="contact.html">SUBMIT AN OPPORTUNITY</a></div></section>
"""
    # noun fix (pluralisation handled in JS: 'opportunit' + 's'/'')
    body = body.replace('data-noun="opportunit"', 'data-noun="opportunity"')
    return page("opportunities.html", "Opportunities Corner", "Searchable jobs, scholarships, business opportunities, training programmes, tenders and government programmes for the people of Bulamogi.", body, scripts=("search.js",))


def build_community():
    secs = ""
    for sid, label, icon, kind in COMMUNITY_SECTIONS:
        items = ""
        for c in [x for x in COMMUNITY if x["sec"] == sid]:
            body = paras(c["body"]) + '<p><span class="demo-badge">Demonstration content</span></p>'
            items += (f'<div class="col-md-6 col-lg-4 js-item detail-card" id="{c["id"]}" data-text="{e((c["title"] + " " + c["desc"] + " " + label).lower())}">'
                      f'<article class="card-x event-card"><div class="card-body-x"><div class="d-flex gap-3 align-items-start mb-2">'
                      f'<div class="date-box"><b>{c["day"]}</b><span>{c["mon"]}</span></div><div><span class="type-badge {kind}">{e(label)}</span>'
                      f'<h3 class="detail-title mt-2">{e(c["title"])}</h3></div></div><p>{e(c["desc"])}</p>'
                      f'<div class="meta"><i class="fa-solid fa-location-dot" aria-hidden="true"></i>{e(c["where"])}</div>'
                      f'<div class="push"><a class="read-more js-detail" href="#{c["id"]}">DETAILS <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a></div></div>'
                      f'<div class="detail-body d-none">{body}</div><div class="detail-meta-src d-none">{e(label)}</div></article></div>')
        secs += (f'<section class="js-section pt-4" id="{sid}" aria-labelledby="h-{sid}"><h2 class="h3 mb-4" id="h-{sid}"><i class="fa-solid {icon} text-warning me-2" aria-hidden="true"></i>{e(label)}</h2><div class="row g-4">{items}</div></section>')
    jump = "".join(f'<a class="chip" href="#{sid}">{e(l)}</a>' for sid, l, _, _ in COMMUNITY_SECTIONS) + '<a class="chip" href="#gallery">Photo Gallery</a>'
    gal = "".join(f'<div class="col-6 col-md-3"><div class="gallery"><a href="assets/images/community/{f}" data-lightbox data-caption="{e(a)}">{img("assets/images/community/" + f, a, w=400, h=300)}</a></div></div>' for f, a in GALLERY)
    body = page_hero("Community Announcements", "Meetings, celebrations, condolences, events and important announcements from across the Bulamogi family.", "Community") + f"""
<section class="pb-5"><div class="container js-filter-root" data-noun="announcement">
  <div class="toolbar"><form role="search" class="search-box" aria-label="Search announcements"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
    <label class="visually-hidden" for="commSearch">Search announcements</label><input class="form-control js-search" id="commSearch" type="search" placeholder="Search announcements..."></form>
    <div class="chips" aria-label="Jump to a section">{jump}</div></div>
  <div class="quote-band mt-4">Whether it is a wedding, graduation, birth, achievement, illness, loss or any other significant life event, we want everyone to feel that they are part of a family that cares.</div><p class="demo-note mt-3 mb-0"><i class="fa-solid fa-circle-info me-2" aria-hidden="true"></i>All announcements here are <strong>demonstration samples</strong>. No real person is named in the condolence examples.</p>
  <p class="result-count js-count" aria-live="polite"></p>
  {secs}
  <div class="js-empty empty-state" hidden><i class="fa-regular fa-face-frown" aria-hidden="true"></i><h2 class="h5">No announcements match your search</h2></div>
</div></section>
<section class="section section-grey" id="gallery" aria-labelledby="h-gallery"><div class="container">
  {section_head("Community moments", '<span id="h-gallery">Photo Gallery</span>', "Select an image to enlarge it. These illustrations are placeholders for real community photographs.")}
  <div class="row g-3">{gal}</div></div></section>
{cta_section()}
"""
    return page("community.html", "Community Announcements", "Community meetings, celebrations, condolences, events and important announcements from the Bulamogi family, with a photo gallery.", body, scripts=("search.js",))


def build_contact():
    ep = ' data-endpoint="%s"' % FORM_ENDPOINT if FORM_ENDPOINT else ""
    badge = "" if FORM_ENDPOINT else '<span class="demo-badge mb-3">Demonstration form &ndash; not connected to a mail service</span>'
    body = page_hero("Contact Us", "We would love to hear from you: news tips, celebrations, announcements, nominations or questions.", "Contact Us") + f"""
<section class="section"><div class="container"><div class="row g-5">
  <div class="col-lg-5 reveal">
    <span class="kicker">Get in touch</span><h2>Let's connect</h2>
    <p class="text-muted">Our platform runs on WhatsApp, so it is the fastest way to reach us. The email and physical address below are placeholders until the official details are added.</p>
    <div class="contact-card"><div class="ic"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></div><div><h3>Location</h3><p>Bulamogi, Uganda<br><small>(physical address to be added)</small></p></div></div>
    <div class="contact-card"><div class="ic"><i class="fa-solid fa-envelope" aria-hidden="true"></i></div><div><h3>Email</h3><p><a href="mailto:{CONTACT_EMAIL}">{CONTACT_EMAIL}</a></p></div></div>
    <div class="contact-card"><div class="ic"><i class="fa-solid fa-phone" aria-hidden="true"></i></div><div><h3>Phone / WhatsApp</h3><p><a href="tel:+{WHATSAPP_NUMBER}">{CONTACT_PHONE}</a></p></div></div>
    <div class="contact-card"><div class="ic"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i></div><div><h3>WhatsApp (fastest)</h3><p>Admin: {WHATSAPP_ADMIN}<br><a href="{WA_LINK}" target="_blank" rel="noopener noreferrer">Chat with us on WhatsApp</a></p></div></div>
    <h3 class="h6 mt-4">Follow us</h3><div class="social-big">{social_links()}</div>
  </div>
  <div class="col-lg-7 reveal d1">
    <div class="card-x p-4" id="message">{badge}<h2 class="h4">Send us a message</h2>
      <form class="js-form" novalidate{ep}>
        <input type="text" name="_gotcha" class="d-none" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label" for="c-name">Full name</label><input class="form-control" id="c-name" name="name" required autocomplete="name"><div class="invalid-feedback">Please enter your name.</div></div>
          <div class="col-md-6"><label class="form-label" for="c-email">Email address</label><input class="form-control" id="c-email" type="email" name="email" required autocomplete="email"><div class="invalid-feedback">Enter a valid email address.</div></div>
          <div class="col-12"><label class="form-label" for="c-topic">Topic</label><select class="form-select" id="c-topic" name="topic" required><option value="">Choose a topic...</option><option>News tip</option><option>Celebration announcement</option><option>Condolence or support notice</option><option>Nominate a person</option><option>Submit an opportunity</option><option>General question</option></select><div class="invalid-feedback">Please choose a topic.</div></div>
          <div class="col-12"><label class="form-label" for="c-msg">Message</label><textarea class="form-control" id="c-msg" name="message" rows="5" required data-minlength="10"></textarea><div class="invalid-feedback">Please write at least 10 characters.</div></div>
          <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="c-ok" name="consent" required><label class="form-check-label small" for="c-ok">I agree that the Bulamogi Media Community team may contact me about this message.</label><div class="invalid-feedback">Please tick to continue.</div></div></div>
          <div class="col-12"><button class="btn btn-gold" type="submit"><i class="fa-solid fa-paper-plane me-2" aria-hidden="true"></i>SEND MESSAGE</button></div>
        </div><div class="form-status" aria-live="polite"></div>
      </form></div>
  </div>
</div></div></section>

<section class="section section-grey" id="join" aria-labelledby="join-title"><div class="container"><div class="row justify-content-center"><div class="col-lg-8 reveal">
  <div class="text-center mb-4"><span class="kicker">Become part of the family</span><h2 id="join-title">Join Our Community</h2>
    <p class="text-muted">Tell us a little about yourself and how you would like to stay connected. Or message us directly on WhatsApp.</p>
    <a class="btn btn-navy btn-sm-x" href="{WHATSAPP_GROUP or WA_LINK}" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-whatsapp me-1" aria-hidden="true"></i>{"Join the WhatsApp group" if WHATSAPP_GROUP else "Message us on WhatsApp"}</a></div>
  <div class="card-x p-4">{badge}
    <form class="js-form" novalidate{ep}>
      <input type="text" name="_gotcha" class="d-none" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div class="row g-3">
        <div class="col-md-6"><label class="form-label" for="j-name">Full name</label><input class="form-control" id="j-name" name="name" required><div class="invalid-feedback">Please enter your name.</div></div>
        <div class="col-md-6"><label class="form-label" for="j-where">Where do you live? (town / country)</label><input class="form-control" id="j-where" name="location" required><div class="invalid-feedback">Please tell us where you live.</div></div>
        <div class="col-12"><label class="form-label" for="j-contact">Email address</label><input class="form-control" id="j-contact" type="email" name="email" required><div class="invalid-feedback">Enter a valid email address.</div></div>
        <div class="col-12"><button class="btn btn-gold" type="submit">JOIN OUR COMMUNITY</button></div>
      </div><div class="form-status" aria-live="polite"></div>
    </form></div>
</div></div></div></section>
"""
    return page("contact.html", "Contact Us", "Contact Bulamogi Media Community by WhatsApp, email or message form to share news, celebrations, announcements, nominations and opportunities.", body)


# =====================================================================
# WRITE FILES
# =====================================================================
def write(name, content):
    with open(os.path.join(ROOT, name), "w", encoding="utf-8") as f:
        f.write(content)


# news_card returns None when detail=False (home uses its own markup), keep helper strict
BUILDERS = {"index.html": build_home, "about.html": build_about, "news.html": build_news, "programmes.html": build_programmes,
            "people.html": build_people, "opportunities.html": build_opps, "community.html": build_community, "contact.html": build_contact}

if __name__ == "__main__":
    for fname, fn in BUILDERS.items():
        write(fname, fn())
    sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for fname, pr in PAGES:
        loc = SITE_URL + "/" + ("" if fname == "index.html" else fname)
        sm.append("  <url><loc>%s</loc><lastmod>%s</lastmod><changefreq>weekly</changefreq><priority>%.1f</priority></url>" % (loc, LASTMOD, pr))
    sm.append("</urlset>")
    write("sitemap.xml", "\n".join(sm) + "\n")
    write("robots.txt", "User-agent: *\nAllow: /\n\nSitemap: %s/sitemap.xml\n" % SITE_URL)
    write(".nojekyll", "")
    print("Built", ", ".join(BUILDERS))
