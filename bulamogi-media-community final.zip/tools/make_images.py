#!/usr/bin/env python3
"""Generates the brand artwork and placeholder illustrations (SVG) for the site.

Run from anywhere:  python3 tools/make_images.py
Replace any generated file with a real photo (same name, .jpg/.webp) and update the
matching <img src> in tools/build.py to use real photography.
"""
import os
import random

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(ROOT, "assets", "images")
ICONS = os.path.join(ROOT, "assets", "icons")
for d in ("news", "programmes", "community", "people"):
    os.makedirs(os.path.join(IMG, d), exist_ok=True)
os.makedirs(ICONS, exist_ok=True)

NAVY, BLUE, GOLD = "#102A43", "#1769AA", "#E0A526"


def save(folder, rel, content):
    with open(os.path.join(folder, rel), "w", encoding="utf-8") as f:
        f.write(content)


# (the official logo is a supplied file: assets/images/logo.png / logo.jpg)

# ---------------------------------------------------------------- hero
random.seed(7)
birds = "".join(
    f'<path d="M{x} {y} q12 -14 24 0 q12 -14 24 0" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="3" stroke-linecap="round"/>'
    for x, y in [(300, 220), (380, 180), (470, 250), (1050, 200), (1130, 160)])


def person(x, y, s=1.0, c="#0b1f33"):
    return (f'<g transform="translate({x},{y}) scale({s})" fill="{c}">'
            f'<circle cx="0" cy="-62" r="13"/><path d="M-20 0 v-32 a20 20 0 0 1 40 0 v32 z"/></g>')


people = "".join(person(x, y, s) for x, y, s in
                 [(1000, 800, 1.5), (1070, 812, 1.7), (1145, 800, 1.45), (1215, 815, 1.65), (1290, 802, 1.4), (1355, 812, 1.55)])
save(IMG, "hero.svg", f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b2239"/><stop offset=".45" stop-color="{BLUE}"/><stop offset=".8" stop-color="#f0b84a"/><stop offset="1" stop-color="{GOLD}"/></linearGradient>
<radialGradient id="glow"><stop offset="0" stop-color="#fff3c4" stop-opacity=".95"/><stop offset="1" stop-color="#fff3c4" stop-opacity="0"/></radialGradient>
<linearGradient id="lake" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3c565" stop-opacity=".9"/><stop offset="1" stop-color="{BLUE}"/></linearGradient>
</defs>
<rect width="1600" height="900" fill="url(#sky)"/>
<circle cx="1150" cy="560" r="260" fill="url(#glow)"/>
<circle cx="1150" cy="560" r="85" fill="#ffe08a"/>
{birds}
<path d="M0 600 L220 470 L420 580 L640 450 L860 590 L1100 500 L1340 600 L1600 520 V900 H0Z" fill="#1c4f7a" opacity=".75"/>
<rect x="0" y="600" width="1600" height="140" fill="url(#lake)" opacity=".85"/>
<path d="M0 690 C250 620 480 700 760 660 C1040 620 1300 700 1600 650 V900 H0Z" fill="#0f3556"/>
<path d="M0 770 C300 720 600 800 900 760 C1200 720 1400 790 1600 750 V900 H0Z" fill="#0b2239"/>
{people}
</svg>""")

# ---------------------------------------------------------------- scenes
PAL = {
    "navy": ("#102A43", "#1769AA", "#E0A526"),
    "blue": ("#1769AA", "#2b8bd6", "#ffd166"),
    "gold": ("#b9801a", "#E0A526", "#102A43"),
    "teal": ("#0f4c5c", "#2a9d8f", "#E0A526"),
    "plum": ("#3b2a55", "#6a4c93", "#E0A526"),
    "slate": ("#243b53", "#486581", "#d9e2ec"),
    "green": ("#14532d", "#2e8b57", "#E0A526"),
}


def m_sun(): return f'<circle cx="400" cy="230" r="75" fill="#ffd166"/>' + "".join(
    f'<line x1="{400+95*c}" y1="{230+95*s}" x2="{400+125*c}" y2="{230+125*s}" stroke="#ffd166" stroke-width="8" stroke-linecap="round"/>'
    for c, s in [(1, 0), (.7, .7), (0, 1), (-.7, .7), (-1, 0), (-.7, -.7), (0, -1), (.7, -.7)])


def m_broadcast(): return ('<circle cx="400" cy="260" r="24" fill="#fff"/>' + "".join(
    f'<path d="M{400-r} {260} A{r} {r} 0 0 1 {400+r} {260}" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" opacity="{o}"/>'
    for r, o in [(60, .9), (105, .7), (150, .5)]))


def m_people(): return "".join(
    f'<circle cx="{x}" cy="190" r="32" fill="#fff" opacity=".92"/><path d="M{x-48} 340 a48 48 0 0 1 96 0z" fill="#fff" opacity=".85"/>'
    for x in (300, 400, 500))


def m_book(): return ('<path d="M400 190 C350 165 290 165 250 180 V330 C290 315 350 315 400 340Z" fill="#fff" opacity=".92"/>'
                      '<path d="M400 190 C450 165 510 165 550 180 V330 C510 315 450 315 400 340Z" fill="#fff" opacity=".8"/>')


def m_heart(): return '<path d="M400 340 C270 255 290 150 355 160 C385 165 400 188 400 198 C400 188 415 165 445 160 C510 150 530 255 400 340Z" fill="#fff" opacity=".92"/>'


def m_globe(): return ('<circle cx="400" cy="245" r="105" fill="none" stroke="#fff" stroke-width="8"/>'
                       '<ellipse cx="400" cy="245" rx="45" ry="105" fill="none" stroke="#fff" stroke-width="6"/>'
                       '<line x1="295" y1="245" x2="505" y2="245" stroke="#fff" stroke-width="6"/>'
                       '<path d="M310 190 H490 M310 300 H490" stroke="#fff" stroke-width="5" fill="none"/>')


def m_brief(): return ('<rect x="320" y="200" width="160" height="110" rx="14" fill="#fff" opacity=".92"/>'
                       '<path d="M365 200 v-22 h70 v22" fill="none" stroke="#fff" stroke-width="10"/>'
                       '<rect x="320" y="245" width="160" height="10" fill="#E0A526"/>')


def m_party():
    random.seed(3)
    dots = "".join(
        f'<circle cx="{random.randint(230, 570)}" cy="{random.randint(120, 350)}" r="{random.randint(5, 11)}" fill="{random.choice(["#fff", "#ffd166", "#ff9aa2", "#9be7ff"])}" opacity=".9"/>'
        for _ in range(34))
    return dots + '<path d="M400 190 l16 36 40 4 -30 27 9 39 -35 -21 -35 21 9 -39 -30 -27 40 -4z" fill="#fff"/>'


def m_cap(): return ('<polygon points="400,175 540,230 400,285 260,230" fill="#fff" opacity=".95"/>'
                     '<path d="M320 260 v50 c50 30 110 30 160 0 v-50 l-80 32z" fill="#fff" opacity=".8"/>'
                     '<line x1="535" y1="235" x2="535" y2="310" stroke="#ffd166" stroke-width="6"/>')


def m_chart(): return "".join(
    f'<rect x="{x}" y="{340-h}" width="46" height="{h}" rx="6" fill="#fff" opacity="{o}"/>'
    for x, h, o in [(290, 70, .7), (350, 110, .8), (410, 150, .9), (470, 195, 1)])


def m_cross(): return ('<rect x="365" y="165" width="70" height="170" rx="14" fill="#fff" opacity=".95"/>'
                       '<rect x="315" y="215" width="170" height="70" rx="14" fill="#fff" opacity=".95"/>')


def m_candle(): return ('<rect x="375" y="215" width="50" height="125" rx="8" fill="#fff" opacity=".92"/>'
                        '<path d="M400 150 C375 185 380 205 400 205 C420 205 425 185 400 150Z" fill="#ffd166"/>')


def m_mic(): return ('<rect x="372" y="150" width="56" height="110" rx="28" fill="#fff" opacity=".95"/>'
                     '<path d="M340 235 a60 60 0 0 0 120 0" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round"/>'
                     '<line x1="400" y1="295" x2="400" y2="335" stroke="#fff" stroke-width="10"/>'
                     '<line x1="365" y1="338" x2="435" y2="338" stroke="#fff" stroke-width="10" stroke-linecap="round"/>')


MOTIFS = dict(sun=m_sun, broadcast=m_broadcast, people=m_people, book=m_book, heart=m_heart, globe=m_globe,
              brief=m_brief, party=m_party, cap=m_cap, chart=m_chart, cross=m_cross, candle=m_candle, mic=m_mic)


def scene(folder, name, pal, motif):
    a, b, c = PAL[pal]
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient></defs>
<rect width="800" height="500" fill="url(#g)"/>
<circle cx="680" cy="90" r="150" fill="#fff" opacity=".06"/><circle cx="90" cy="420" r="190" fill="#fff" opacity=".05"/>
{MOTIFS[motif]()}
<path d="M0 420 C160 380 300 450 470 410 C610 380 700 430 800 400 V500 H0Z" fill="#000" opacity=".22"/>
<path d="M0 455 C200 425 360 480 520 450 C650 425 730 465 800 445 V500 H0Z" fill="{c}" opacity=".85"/>
</svg>"""
    save(os.path.join(IMG, folder), name, svg)


SCENES = {
    "news": [("n1.svg", "navy", "people"), ("n2.svg", "plum", "cap"), ("n3.svg", "teal", "cross"),
             ("n4.svg", "gold", "chart"), ("n5.svg", "blue", "mic"), ("n6.svg", "navy", "globe"),
             ("n7.svg", "green", "people"), ("n8.svg", "slate", "book")],
    "programmes": [("bulamogi-today.svg", "navy", "mic"), ("people-of-bulamogi.svg", "blue", "people"),
                   ("our-community-our-responsibility.svg", "green", "people"), ("celebrating-with-you.svg", "plum", "party"),
                   ("together-in-difficult-times.svg", "slate", "candle"), ("bulamogi-worldwide.svg", "navy", "globe"),
                   ("opportunities-corner.svg", "gold", "brief")],
    "community": [("c1.svg", "navy", "people"), ("c2.svg", "plum", "party"), ("c3.svg", "teal", "cap"),
                  ("c4.svg", "green", "sun"), ("c5.svg", "blue", "broadcast"), ("c6.svg", "gold", "heart"),
                  ("c7.svg", "slate", "candle"), ("c8.svg", "navy", "mic")],
}
for folder, items in SCENES.items():
    for name, pal, motif in items:
        scene(folder, name, pal, motif)

# ---------------------------------------------------------------- avatars
for i, (pal, hair) in enumerate([("navy", "#102A43"), ("teal", "#0f4c5c"), ("plum", "#3b2a55"),
                                 ("blue", "#0d4a7a"), ("green", "#14532d"), ("gold", "#7a5410")], 1):
    a, b, c = PAL[pal]
    save(os.path.join(IMG, "people"), f"p{i}.svg", f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient></defs>
<rect width="400" height="400" fill="url(#g)"/>
<circle cx="200" cy="150" r="62" fill="#fff" opacity=".93"/>
<path d="M70 400 a130 130 0 0 1 260 0z" fill="#fff" opacity=".88"/>
<circle cx="200" cy="150" r="62" fill="none" stroke="{c}" stroke-width="5" opacity=".9"/>
</svg>""")

print("Images generated in", IMG)
